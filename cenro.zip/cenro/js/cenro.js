jQuery(document).ready(function(){
    jQuery('.integer').filter_input({regex:"[0-9]"});
    jQuery('.decimal').filter_input({regex:"[0-9-(.)]"});
	jQuery('.createButton, .returnButton').click(function(){
		jQuery(location).attr("href", jQuery(this).attr("location"));
	});
	jQuery('.updateButton').click(function(){
		var items = new Array;
	    jQuery(jQuery(this).attr('data-set')).each(function(){
			checked = this.checked? true : false;
			if(checked) {
				items.push(jQuery(this).attr("value"));
			}
	    });
	    if(items.length==1) {
	    	jQuery(location).attr("href", jQuery(this).attr("location") + "/" +items[0]);
	    } else if(items.length>1) {
	    	popup_box({content:"This operation cannot be performed on more than one item. Select a single item and try again."}, {close:"OK"});
	    } else {
	    	popup_box({content:"There is no selected item."}, {close:"OK"});
	    }
	});
	jQuery('.deleteButton').click(function(){
		var donelink = jQuery(this).attr("location");
		var ajaxlink = jQuery(this).attr("ajaxlink");

		var items = new Array;
	    jQuery(jQuery(this).attr('data-set')).each(function(){
	    	checked = this.checked? true : false;
	    	if(checked) {
	        	items.push(jQuery(this).attr("value"));
	    	}
	    });
	    if(items.length) {
	    	if(confirm("Delete selected " + ((items.length>1)? "items" : "item") + "?")) {
	    		jQuery.ajax({
					url: ajaxlink,
					type:"POST",
					data:{items:items}
		       	}).done(function(e){
		       		jQuery(location).attr("href", donelink);
	       		});
	    	}
	    } else
	    	popup_box({content:"There are no selected items."}, {close:"OK"});
	});

    var signOut = randomstring(5);
    jQuery("#signOut").click(function(){
        var out = jQuery(this).attr("location");
        var div = jQuery("<div></div");
        div.append("<p>Signing out of system will end your session.<p>");
        div.append("<p>Do you want to proceed?<p>");
        if(!jQuery("div#"+signOut).length) popup_box({title:"Confirmation",content:div, class:signOut}, {submit:true, name:"sign-out", id:"sign-out", class:"btn-primary", value:"Proceed", click:function(){jQuery(location).attr("href", out)}, close:"Cancel"});
    });
});

function popup_box( options, buttons ){
    var options_defaults = {
        title: "Message",
        content: "Please provide a text...",
        width: false,
        height:false,
        start: false,
        place: false,
        class: "xxx",
        positionTop: 0
    }
    var buttons_defaults = { submit:false, name:false, id:false, class:false, value:false, close:false, click:false }
    var options = jQuery.extend(options_defaults, options);
    var buttons = jQuery.extend(buttons_defaults, buttons);
    var buts = '';
    if(buttons.submit){
        buts += "<input type='submit' name='"+buttons.name+"' id='"+buttons.id+"' value='"+buttons.value+"' class='popup_triggers "+buttons.class+"'>";
    }
    if(buttons.close!=false) buts += createButton(buttons.close);
    function createButton(value){
        return "<input type='button' value='"+value+"' class='stdbtn esc"+options.class+"'>";
    }
    var popup_container = jQuery("<div></div>", { class : "uiBSpopupwin"});
    var popup_header= jQuery("<div></div>", { class : "popupwinHeader contenttitle" });
    var popup_close = jQuery("<span></span>", { class : "popup_closers" }).attr('title', 'Close').append('&#10006;');
    var popup_title = jQuery(popup_header).append(jQuery("<h2><span>"+options.title+"</span></h2>")).append(popup_close);
    var popup_content = jQuery("<div></div>", { class : "popup_content" }).append(options.content);
    var popup_modal = jQuery("<div></div>", { class : "uiBSgeneric_dialog_modal" , id:options.class});
    if(options.width!=false) jQuery(popup_container).css({"width":options.width + 'px'});
    if(options.height!=false) jQuery(popup_content).css({"max-height":options.height + 'px',"overflow":"auto"});
    if(options.start!=false) {
        var popup_form = jQuery(options.start);
        jQuery(popup_form).append(popup_title).append(popup_content).css({"margin":0});
        if(buts!=''){
            var popup_buttons = jQuery("<div></div>", { class : "popup_buttons" }).html(buts);
            jQuery(popup_form).append(popup_buttons);
        }
        jQuery(popup_container).append(popup_form);
    } else {
        jQuery(popup_container).append(popup_title).append(popup_content);
        if(buts!=''){
            var popup_buttons = jQuery("<div></div>", { class : "popup_buttons" }).html(buts);
            jQuery(popup_container).append(popup_buttons);
        }
    }
    if(typeof buttons.click == 'function') {
        popup_buttons.find('input').each(function(){
            if(jQuery(this).attr("id")==buttons.id) jQuery(this).click(function(){buttons.click()});
        });
    }
    jQuery(popup_modal).append(popup_container);
    jQuery("body").append(popup_modal);
    var top, left;
    top = Math.max(jQuery(window).height() - jQuery(popup_container).outerHeight(), 0) / 2;
    left = Math.max(jQuery(window).width() - jQuery(popup_container).outerWidth(), 0) / 2;
    if(options.positionTop > 0) {
        top += jQuery(window).scrollTop();
    } else {
        top += options.positionTop;
    }
    jQuery(popup_container).css({"top": top, "left": left + jQuery(window).scrollLeft()});
    jQuery(popup_close).click(function(){
        jQuery("#"+options.class).remove();
        if(options.place){
            jQuery("#main").append(options.content);
            jQuery(options.content).hide();
        }
    });
    jQuery(".esc"+options.class).click(function(){ jQuery(popup_close).click(); });
}

function filterInput(className){
    var success = true;
    jQuery('.'+className).css({'border-color':'rgba(82, 168, 236, 0.8)', 'box-shadow':'0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6)', 'outline':'0 none'});
    jQuery('.'+className).each(function(){
        jQuery(this).val(jQuery.trim(jQuery(this).val()));
        if(jQuery.trim(jQuery(this).val()) == '') {
            jQuery(this).css('border', 'solid thin red');
            success = (success)? jQuery(this).focus(): '';
            success = false;
        }
    });
    return success;
}

function randomstring(L){
    var s= '';
    var randomchar=function(){
        var n= Math.floor(Math.random()*62);
        if(n<10) return n; //1-10
        if(n<36) return String.fromCharCode(n+55); //A-Z
        return String.fromCharCode(n+61); //a-z
    }
    while(s.length< L) s+= randomchar();
    return s;
}

(function($){  
  
    $.fn.extend({   

        filter_input: function(options) {  

          var defaults = {  
              regex:".*",
              live:false
          }  
                
          var options =  $.extend(defaults, options);  
          var regex = new RegExp(options.regex);
          
          function filter_input_function(event) {

            var key = event.charCode ? event.charCode : event.keyCode ? event.keyCode : 0;

            // 8 = backspace, 9 = tab, 13 = enter, 35 = end, 36 = home, 37 = left, 39 = right, 46 = delete
            if (key == 8 || key == 9 || key == 13 || key == 35 || key == 36|| key == 37 || key == 39 || key == 46) 
            {
              //allow backspace
              if(key == 8) return true;

              if ($.browser.mozilla) 
              {

                // if charCode = key & keyCode = 0
                // 35 = #, 36 = $, 37 = %, 39 = ', 46 = .
         
                if (event.charCode == 0 && event.keyCode == key) {
                  return true;                                             
                }
              }
            }


            var string = String.fromCharCode(key);
            if (regex.test(string)) {
              return true;
            } 
            return false;
          }
          
          if (options.live) {
            $(this).live('keypress', filter_input_function); 
          } else {
            return this.each(function() {  
              var input = $(this);
              input.unbind('keypress').keypress(filter_input_function);
            });  
          }
          
        }  
    });  
      
})(jQuery);