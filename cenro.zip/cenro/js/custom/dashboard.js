jQuery(document).ready(function(){
	
	jQuery('#datepicker').datepicker();

	jQuery('.widgetlist a').hover(function(){
		jQuery(this).switchClass('default', 'hover');
	},function(){
		jQuery(this).switchClass('hover', 'default');
	});

});