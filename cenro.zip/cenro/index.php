<?php 
  define("BASE_ROOT", getcwd());
  define("VIEW_PATH", BASE_ROOT . "/inc/");
  define("LIBRARIES", BASE_ROOT . "/lib/");
  include BASE_ROOT . '/php/core.php';
  include BASE_ROOT . '/php/user.php';
  include BASE_ROOT . '/php/image.php';
  include BASE_ROOT . '/php/data.php';
  include BASE_ROOT . '/php/page.php';
  define("BASE_PATH", baseURL());
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title><?php print $CONTENT['title'] . " | " . WEBNAME ?></title>
        <link rel="stylesheet" href="<?php echo BASE_PATH ?>css/style.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo BASE_PATH ?>css/green.css" type="text/css" />
        <link rel="stylesheet" href="<?php echo BASE_PATH . "css/cenro.css?" . randomString(10) ?>" type="text/css" />
        <script type="text/javascript">var BASE_PATH = "<?php echo BASE_PATH ?>"</script>
        <?php foreach ($CONTENT['script'] as $js): ?>
        <script type="text/javascript" src="<?php echo BASE_PATH . "js/" . $js ?>"></script>
        <?php endforeach ?>
    </head>
    <body class="loggedin">
        <?php if($CONTENT['header']): ?>
        <div class="header radius3"><?php print getContents("header") ?></div>
        <?php endif ?>
        <div class="mainwrapper"><?php print $CONTENT['content'] ?></div> 
    </body>
    <script type="text/javascript" src="<?php echo BASE_PATH . "js/cenro.js?" . randomString(10) ?>"></script>
    <script type="text/javascript">
    jQuery(document).ready(function(){
      jQuery(".leftmenu ul").find("li").each(function(){
        if(jQuery(this).hasClass("<?php print $METHOD ?>")) jQuery(this).addClass('current');
      });
    });
    </script>
</html>
