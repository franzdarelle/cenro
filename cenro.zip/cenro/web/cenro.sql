-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2016 at 05:52 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cenro`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE IF NOT EXISTS `applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `company` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `requirements` text NOT NULL,
  `violations` text NOT NULL,
  `history` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `remarks` varchar(255) NOT NULL,
  `recommendation` smallint(1) NOT NULL,
  `actionOn` varchar(10) NOT NULL,
  `actionBy` varchar(50) NOT NULL,
  `status` smallint(1) NOT NULL,
  `deleted` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `pid`, `sid`, `uid`, `fname`, `lname`, `mname`, `company`, `address`, `requirements`, `violations`, `history`, `created`, `updated`, `remarks`, `recommendation`, `actionOn`, `actionBy`, `status`, `deleted`) VALUES
(1, 0, 2, 2, 'Alden', 'Carpio', '', 'AMS Asia Inc.', 'Carmelray II, Bukal, Calamba City, Laguna', '', '', '', '2016-01-20 22:31:05', '2016-02-21 22:44:41', 'OK', 0, '', '', 1, 1),
(2, 0, 1, 3, 'Kevin', 'Adlaon', '', 'SPI Technologies', 'Carmelray II, Bukal, Calamba City, Laguna', '', '', '', '2016-01-20 23:04:39', '2016-02-21 22:44:41', 'OK', 0, '', '', 1, 1),
(3, 0, 1, 2, 'Bart Darelle', 'San Luis', '', 'Dota2Sport', 'Canlubang, Calamba City, Laguna', '', '', '', '2016-01-23 21:53:18', '2016-02-21 22:44:41', 'OK', 0, '', '', 1, 1),
(4, 0, 1, 3, 'Liza Marie', 'Carpio', '', 'Wyeth Nutrition Philippines', 'Canlubang, Calamba City, Laguna', '', '', '', '2016-01-23 23:53:30', '2016-02-21 22:44:41', 'No ECC and CNC ', 0, '', '', 0, 1),
(5, 1, 1, 2, 'Franz Darelle', 'Macatangga', '', 'SS Canteen', 'Brgy. San Juan, Kalayaan, Laguna', '{"9":{"pdf_file":"iolsmxbkdq.pdf","approved":"1"},"10":{"pdf_file":"6vtdrwfrlk.pdf","approved":"1"},"11":{"pdf_file":"1itjhayr9a.pdf","approved":"1"},"12":{"pdf_file":"ouegf7pqt1.pdf","approved":"1"},"13":{"pdf_file":"bwv4tnczyb.pdf","approved":"1"},"14":{"pdf_file":"1muppeotfy.pdf","approved":"1"},"15":{"pdf_file":"nk4odbyv6y.pdf","approved":"1"}}', '', '', '2016-02-08 15:38:33', '2016-02-21 22:44:41', 'OK', 4, '', '', 2, 1),
(6, 1, 2, 3, 'Christian', 'Vergara', '', 'AMS Asia', 'Calamba City, Laguna', '{"1":{"pdf_file":"pxdzewktxt.pdf","approved":"1"},"2":{"pdf_file":"nyq4vobeeh.pdf","approved":"1"},"3":{"pdf_file":"fuwlq8cokb.pdf","approved":"1"},"4":{"pdf_file":"utfqmzjhac.pdf","approved":"1"},"5":{"pdf_file":"qnciegpwvo.pdf","approved":"1"},"6":{"pdf_file":"id2mth1s0a.pdf","approved":"1"},"7":{"pdf_file":"2szmajshoh.pdf","approved":"1"},"8":{"pdf_file":"4jytd0ebk6.pdf","approved":"1"}}', '', '', '2016-02-08 22:12:01', '2016-02-21 22:44:41', 'OK', 2, '', '', 1, 1),
(7, 2, 16, 2, 'Audie', 'Cada', '', 'SPI Technologies', 'Calamba City, Laguna', '{"52":{"pdf_file":"f5kebhlzzx.pdf","approved":"1"}}', '', '', '2016-02-10 14:26:55', '2016-02-22 01:50:37', 'OK', 1, '03/28/2016', 'Renan Miranda', 1, 0),
(8, 1, 1, 3, 'Henry', 'Sapungan', '', 'Wyeth Nutrition Philippines', 'Carmel Ray II, Canlubang, Calamba City, Laguna', '{"9":{"pdf_file":"0gex23ig15.pdf","approved":"1"},"10":{"pdf_file":"x0s3h9mquc.pdf","approved":"1"},"11":{"pdf_file":"uhehcmgoli.pdf","approved":"1"},"12":{"pdf_file":"xa4ffq59yp.pdf","approved":"1"},"13":{"pdf_file":"red6nlzrly.pdf","approved":"1"},"14":{"pdf_file":"zxq9zyokeh.pdf","approved":"1"},"15":{"pdf_file":"ub7dcwamrl.pdf","approved":"1"}}', '', '', '2016-02-10 14:59:18', '2016-02-21 22:44:41', 'OK', 3, '', '', 2, 1),
(9, 1, 1, 2, 'Melvin', 'Ardesa', '', 'Monde', 'Canlubang, Calamba City, Laguna', '{"9":{"pdf_file":"vyhhf9b1rs.pdf","approved":"1"},"10":{"pdf_file":"4b9o1j5u8p.pdf","approved":"1"},"11":{"pdf_file":"","approved":"0"},"12":{"pdf_file":"","approved":"0"},"13":{"pdf_file":"","approved":"0"},"14":{"pdf_file":"","approved":"0"},"15":{"pdf_file":"","approved":"0"}}', '', '', '2016-02-10 17:37:34', '2016-02-21 22:44:41', 'missing files', 0, '', '', 0, 1),
(10, 1, 1, 20, 'Kaye Ann', 'Pabalate', 'Ramos', 'Zenith Food Corporation', 'Canlubang, Calamba City, Laguna', '{"9":{"pdf_file":"2kk4dgaixq.pdf","approved":"1"},"10":{"pdf_file":"aaukhwzjmc.pdf","approved":"1"},"11":{"pdf_file":"2ra4kjofpw.pdf","approved":"1"},"12":{"pdf_file":"fb5lyqgrnx.pdf","approved":"1"},"13":{"pdf_file":"x15rlvcjey.pdf","approved":"1"},"14":{"pdf_file":"msowh469sy.pdf","approved":"1"},"15":{"pdf_file":"fzh0udijls.pdf","approved":"1"}}', '', '', '2016-02-14 23:21:47', '2016-02-22 01:44:22', 'OK', 2, '03/07/2016', 'Artemio Ayson', 2, 0),
(11, 1, 1, 20, 'Eloisa', 'Marquez', 'Alvarado', 'Wyeth Nutrition Philippines', 'Canlubang, Calamba City, Laguna', '{"9":{"pdf_file":"2bupygbfru.pdf","approved":"1"},"10":{"pdf_file":"uo5tygv9om.pdf","approved":"1"},"11":{"pdf_file":"fx2ewjmj7t.pdf","approved":"1"},"12":{"pdf_file":"kdguryxldv.pdf","approved":"1"},"13":{"pdf_file":"z9g0ajhqvj.pdf","approved":"1"},"14":{"pdf_file":"vaf89i4dq2.pdf","approved":"1"},"15":{"pdf_file":"hs4ex58c7m.pdf","approved":"0"}}', '["1","2"]', '["3"]', '2016-02-15 00:55:32', '2016-02-22 02:17:50', 'violations #1 and #2', 0, '', '', 0, 0),
(12, 1, 2, 20, 'Alden', 'Clores', 'Carpio', 'AMS Asia', 'Calamba City, Laguna', '{"1":{"pdf_file":"9stxe4imaj.pdf","approved":"1"},"2":{"pdf_file":"hoq7smcvnw.pdf","approved":"1"},"3":{"pdf_file":"wohruny4cb.pdf","approved":"1"},"4":{"pdf_file":"ubfsfqcbhz.pdf","approved":"1"},"5":{"pdf_file":"d9mes5mxpc.pdf","approved":"1"},"6":{"pdf_file":"v0ztjvxkbf.pdf","approved":"1"},"7":{"pdf_file":"1b3sita6pj.pdf","approved":"1"},"8":{"pdf_file":"e67wtbtciy.pdf","approved":"1"}}', '', '', '2016-02-15 03:26:02', '2016-02-22 01:46:37', 'OK', 1, '02/29/2016', 'Karol Sotelo', 2, 0),
(13, 2, 16, 24, 'Janine', 'Alvarez', 'Coconut', 'Kuykoy Niyogan Inc.', 'Brgy. San Miguel, Pila, Laguna', '{"52":{"pdf_file":"ptcu7mktbb.pdf","approved":"0"}}', '["3"]', '', '2016-02-15 23:48:26', '2016-02-22 02:20:53', 'has violation #3', 0, '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE IF NOT EXISTS `complaints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `photo` varchar(15) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `name`, `photo`, `message`, `date`, `deleted`) VALUES
(1, 'Nardong Putik', 'uvrmekp0ay.png', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sed tristique diam. Suspendisse tempus nibh ac velit interdum rutrum. Aliquam ullamcorper bibendum elit eget egestas. Pellentesque sodales, justo at feugiat sagittis, quam massa luctus leo, et facilisis tortor nibh mollis nulla. Nulla facilisis sem et dolor congue nec porta enim varius. Quisque ac dolor felis, in laoreet est. Sed a urna est. Phasellus sed elementum ipsum. Aliquam a ante vitae orci tincidunt volutpat ut sed tellus. Vivamus feugiat neque vel arcu accumsan eu pulvinar lorem rhoncus. Maecenas eget venenatis lectus. Maecenas eget nisl lectus, sit amet sodales tellus. Vestibulum imperdiet imperdiet metus, placerat mollis mi mattis ac. Suspendisse metus diam, ultrices vel lobortis non, ultricies non libero. Nulla facilisi.', '2016-02-22 17:16:57', 0),
(2, '', 'qbglmv2ory.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean sed tristique diam. Suspendisse tempus nibh ac velit interdum rutrum. Aliquam ullamcorper bibendum elit eget egestas. Pellentesque sodales, justo at feugiat sagittis, quam massa luctus leo, et facilisis tortor nibh mollis nulla. Nulla facilisis sem et dolor congue nec porta enim varius. Quisque ac dolor felis, in laoreet est. Sed a urna est. Phasellus sed elementum ipsum. Aliquam a ante vitae orci tincidunt volutpat ut sed tellus. Vivamus feugiat neque vel arcu accumsan eu pulvinar lorem rhoncus. Maecenas eget venenatis lectus. Maecenas eget nisl lectus, sit amet sodales tellus. Vestibulum imperdiet imperdiet metus, placerat mollis mi mattis ac. Suspendisse metus diam, ultrices vel lobortis non, ultricies non libero. Nulla facilisi.', '2016-02-22 17:52:33', 0);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `position` varchar(50) NOT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `uid`, `pid`, `image`, `lname`, `fname`, `mname`, `email`, `contact`, `address`, `position`, `stamp`) VALUES
(1, 19, 1, 'ujmpfrgsar.jpg', 'Dela Cruz', 'Juan', 'Manlapus', 'juandelacruz@gmail.com', '09124270008', 'Kalayaan, Laguna', 'Validator', '2016-02-14 14:15:21'),
(2, 20, 0, 'v7sgi1kwb9.jpg', 'Adlaon', 'Cassandra', 'Carpio', 'cassandraayesha@gmail.com', '09059703174', 'Bagumbayan, Sta. Cruz, Laguna', 'Encoder', '2016-02-14 14:52:59'),
(3, 24, 0, 'xfurkylksw.jpg', 'Adlaon', 'Kurt Ian', 'Dob', 'adlaonkurt23@gmail.com', '09306789012', 'Brgy. San Miguel, Pila, Laguna', 'Encoder', '2016-02-15 15:46:26'),
(4, 26, 2, 'u8lti6nin3.jpg', 'San Luis', 'Bart Darelle', 'Agoncillo', 'suboroshi@gmail.com', '09985671234', 'San Juan, Kalayaan, Laguna', 'Validator', '2016-02-15 15:51:10');

-- --------------------------------------------------------

--
-- Table structure for table `requirements`
--

CREATE TABLE IF NOT EXISTS `requirements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `deleted` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `requirements`
--

INSERT INTO `requirements` (`id`, `sid`, `name`, `deleted`) VALUES
(1, 2, 'Business Brgy. Clearance w/ CTC', 0),
(2, 2, 'DTI / SEC', 0),
(3, 2, 'ECC', 0),
(4, 2, 'PTO', 0),
(5, 2, 'DP', 0),
(6, 2, 'DENR ID #', 0),
(7, 2, 'CENRO accredited waste hauler', 0),
(8, 2, 'PDEA license', 0),
(9, 1, 'Business Brgy. Clearance w/ CTC', 0),
(10, 1, 'DTI / SEC', 0),
(11, 1, 'ECC', 0),
(12, 1, 'PTO', 0),
(13, 1, 'DP', 0),
(14, 1, 'BFAD', 0),
(15, 1, 'CENRO accredited waste hauler', 0),
(16, 3, 'Business Brgy. Clearance w/ CTC', 0),
(17, 3, 'DTI / SEC', 0),
(18, 3, 'ECC', 0),
(19, 3, 'PTO', 0),
(20, 3, 'DP', 0),
(21, 3, 'DENR ID #', 0),
(22, 3, 'DOH Accreditation', 0),
(23, 3, 'CENRO accredited waste hauler', 0),
(24, 4, 'Business Brgy. Clearance w/ CTC', 0),
(25, 4, 'DTI / SEC', 0),
(26, 4, 'ECC', 0),
(27, 4, 'PTO (generator set)', 0),
(28, 4, 'DP', 0),
(29, 4, 'CENRO accredited waste hauler', 0),
(30, 5, 'Business Brgy. Clearance w/ CTC', 0),
(31, 5, 'DTI / SEC', 0),
(32, 5, 'CNC', 0),
(33, 5, 'Volume of water extracted per month', 0),
(34, 5, 'Sanitary permit from CHO', 0),
(35, 6, 'Business Brgy. Clearance w/ CTC', 0),
(36, 6, 'DTI / SEC', 0),
(37, 6, 'ECC', 0),
(38, 6, 'PTO', 0),
(39, 6, 'DP', 0),
(40, 7, 'Business Brgy. Clearance w/ CTC', 0),
(41, 7, 'CNC for < 1000 sq. meter', 0),
(42, 7, 'ECC for > 1000 sq. meter', 0),
(43, 7, 'Bacteriological test results of swimming pool wate', 0),
(44, 7, 'CENRO accredited waste hauler', 0),
(45, 7, 'DTI / SEC', 0),
(46, 7, 'Certification from water district', 0),
(47, 8, 'Business Brgy. Clearance w/ CTC', 0),
(48, 8, 'DTI / SEC', 0),
(49, 8, 'ECC', 0),
(50, 8, 'Locational clearance from CPDO mini forest park', 0),
(51, 8, 'Waste water treatment facility', 0),
(52, 16, 'DENR ID #', 0);

-- --------------------------------------------------------

--
-- Table structure for table `salt`
--

CREATE TABLE IF NOT EXISTS `salt` (
  `id` int(11) NOT NULL,
  `prefix` text NOT NULL,
  `suffix` text NOT NULL,
  `deleted` smallint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salt`
--

INSERT INTO `salt` (`id`, `prefix`, `suffix`, `deleted`) VALUES
(1, 'bO67PdGUxK', 'YDb4hv9O1E', 0),
(2, 'TJi2mkzo5l', '5fwRPE4Kv6', 1),
(3, 'UHwcDFYt0l', '48lCFLpkiq', 1),
(4, '30hvlOzDeR', 'zGbZMDviy2', 1),
(5, '3za1EtRuVZ', 'Oi7vjNQ89h', 1),
(6, 'ZRr4wf3Gqh', 'FAmtS1zZn0', 1),
(7, 'TAv6UFVK4L', '6EICfUTax2', 1),
(8, 'pTLIoHv9DR', 'xD31YgPNkU', 1),
(9, 'Y2hlmHN3gP', 'qhKfjzx5CY', 1),
(10, 'L2JI6Bli4o', 'tj9df6W1ns', 1),
(11, 'Kpikdj9raR', 'BaHTzS1O9J', 1),
(12, 'A8pokXx9eF', 'QLzdE4rgDn', 1),
(13, 'pa2QhFCPfA', 'ocn4gEdJxP', 1),
(14, '3L0w976sKB', 'KxIglyGc6q', 1),
(15, 'PXQiZjYxUO', 'W2YSKoMxzd', 1),
(16, 'Gg81U76VIA', 'MQlgRYOTiw', 0),
(17, 'DoZ1dy2MUg', 'eQjd9Vw7oN', 1),
(18, 'jJDLV9vEmC', '3LM4ER1w0f', 1),
(19, 'GF6wqjOyPD', 'g2mcuTePxD', 0),
(20, 'QZig2FeOch', 'h7lxqkz4bw', 0),
(21, 'QzqcUbpiT3', '8Lq1VuyKdO', 0),
(22, 'PzeAJl91pI', 'oBYT1SasPw', 0),
(23, 'YNc7LKPJrh', 'TKG5wp9tUx', 0),
(24, 'D3bRasSVKj', 'UYuio6daK2', 0),
(25, 'qHaC7ST4Yb', 'HI8mTPXvSd', 0),
(26, 'kHutxPTCe8', 'W79zh1CLfM', 0);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `deleted` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `pid`, `name`, `description`, `deleted`) VALUES
(1, 1, 'Industrial Establishment Food Clearance', 'Industrial Establishment Food Clearance', 0),
(2, 1, 'Industrial Establishment Non-Food Clearance', 'Industrial Establishment Non-Food Clearance', 0),
(3, 1, 'Hospital & Medical Establishments', 'Hospital & Medical Establishments', 0),
(4, 1, 'Fastfood / Canteen / Restaurant', 'Fastfood / Canteen / Restaurant', 0),
(5, 1, 'Water Refilling Station', 'Water Refilling Station', 0),
(6, 1, 'Funeral Parlor, Crematorium Cemetery', 'Funeral Parlor, Crematorium Cemetery', 0),
(7, 1, 'Resort', 'Resort', 0),
(8, 1, 'Subdivision', 'Subdivision', 0),
(9, 1, 'Junkshop', 'Junkshop', 0),
(10, 1, 'Fabricator', 'Fabricator', 0),
(11, 1, 'Waste Management Facility / MRF / Treater Hauler', 'Waste Management Facility / MRF / Treater Hauler', 0),
(12, 1, 'Commercial Establishment', 'Commercial Establishment', 0),
(13, 1, 'Petroleum Products', 'Petroleum Products', 0),
(14, 1, 'Agricultural Business', 'Agricultural Business', 0),
(15, 1, 'Hauling Services', 'Hauling Services', 0),
(16, 2, 'Forestry Service', 'Forestry Service', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `type` smallint(1) NOT NULL,
  `sque` int(11) NOT NULL,
  `sans` varchar(50) NOT NULL,
  `apps` int(11) NOT NULL,
  `deleted` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user`, `pass`, `type`, `sque`, `sans`, `apps`, `deleted`) VALUES
(1, 'admin_cenro', 'eb277de62ff60791683ee146e703d4d6439cfa99', 3, 2, 'kevz', 0, 0),
(2, 'user1_cenro', 'a749ebaab1c43e7fc18aea976d446a092f94a243', 1, 0, '', 0, 1),
(3, 'user2_cenro', 'f986f452c57e2beb79d77f1c73c589050ddfdcd7', 1, 0, '', 0, 1),
(4, 'kevin', 'ea6903e6f7df74ef91f98eaf5c2063b27ce8b538', 0, 0, '', 0, 1),
(5, 'benjohn', 'f6b04544c121b938309d92a34a44da6742c8ded8', 0, 0, '', 0, 1),
(6, 'suboroshi', '61853f7093d2e16c38062855a53b02372324ef93', 0, 0, '', 0, 1),
(7, 'user3_cenro', '317f7c3df0c2af50cb5acf7c7b2b751ff754fa21', 1, 0, '', 0, 1),
(8, 'apple', '5ccc325a0b9f28c0f0e3aabc30e589bc45ba2b14', 0, 0, '', 0, 1),
(9, 'alden', 'dacb375d10b14a91dc70788a21977be42bfe9da6', 0, 0, '', 1, 1),
(10, 'kevin', '4f1bc6eb459db83e4f25d3c575e0e7d2298ca916', 0, 0, '', 2, 1),
(11, 'bartdarelle', 'a0f167ca450749c894bb7fb55dd882f4c5846882', 0, 0, '', 3, 1),
(12, 'lizamarie', '14c99de7c86cf24b23349e992d8b983fa1ace9b4', 0, 0, '', 4, 1),
(13, 'validator1_cenro', '83953c2f75c27bcc6e97cde4294068235d33b4ef', 2, 0, '', 0, 1),
(14, 'franzdarelle', 'b6a9486bcd7814015fa1110fab9638e7472c956a', 0, 0, '', 5, 1),
(15, 'christian', 'cb80daf0c9d826bc96689f426d4d2bfd82c34f73', 0, 0, '', 6, 1),
(16, 'audie', '021a78c60152165ebaecfdd6f6fced148a92b3bf', 0, 0, '', 7, 0),
(17, 'henry', '46925f2e037153d71389ed78187a2bdd53aaeab2', 0, 0, '', 8, 1),
(18, 'melvin', 'da04fdd459ab9fd01ee2900f2a8ad999cbb68927', 0, 0, '', 9, 1),
(19, 'validator1_cenro', 'd3639ff86404b168031389759bb0669898e6d00d', 2, 0, 'Pila', 0, 0),
(20, 'cassandra', '6b0c1a4756633146cacb78c52e360a25290182c5', 1, 0, '', 0, 0),
(21, 'kayeann', 'f2559a54c6cc6a0c5b96c8bf3cc4226f26b00491', 0, 0, '', 10, 0),
(22, 'eloisa', '0ebaf8065015b97856bef680d6eebb58815432e6', 0, 0, '', 11, 0),
(23, 'alden', '6cd23ff2c3d14b2ff80e1f85c113ffe4010c61e5', 0, 0, '', 12, 0),
(24, 'kurtian', '3763be1d3af97c968ad784f3ab167839d421073f', 1, 0, '', 0, 0),
(25, 'janine', '92822e1750cecd9ab638fd714e517bd1c3b3a347', 0, 0, '', 13, 0),
(26, 'validator2_cenro', 'e6709129012cf26e233c5de720042ac01805bc1c', 2, 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `violations`
--

CREATE TABLE IF NOT EXISTS `violations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `deleted` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `violations`
--

INSERT INTO `violations` (`id`, `name`, `description`, `deleted`) VALUES
(1, 'Violation 1', 'Some description about Violation 1', 0),
(2, 'Violation 2', 'Some description about Violation 2', 0),
(3, 'Violation 3', 'Some description about Violation 3', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
