 <div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print generateUrl('users/applicants') ?>">applicants</a></li>
            </ul>
            <div class="content">            
                <div class="contenttitle radiusbottom0">
                    <h2 class="users"><span>users</span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />   
                        <col class="con0" />                      
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1">&nbsp;</th>
                            <th class="head1">Username</th>
                            <th class="head1">Password</th>    
                            <th class="head1">Company</th>                
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $users = $CENRO->getUsers($type); 
                        if($users):
                            foreach ($users as $user):                                
                                $txtpass = '';
                                $orgpass = $CENRO->getContent($user['file'].".txt");
                                $userapp = $CENRO->getApplication($user['apps']);
                                for($i=0; $i<strlen($orgpass); $i++) $txtpass .= '*';
                    ?>
                        <tr class="gradeX">
                            <td>&nbsp;</td>
                            <td><?php print $user['user'] ?></td>
                            <td class="showPword pointer" pword="<?php print $orgpass ?>"><?php print $txtpass ?></td> 
                            <td><?php print $userapp['company'] ?></td>                             
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){ 
    jQuery("th:first-child, td:first-child").hide().next().css({"border-left":"1px solid #ccc"});
    jQuery('.showPword').click(function(){
        popup_box({class:randomstring(5), title:"Password", content:jQuery("<div></div>", {class:"fluid"}).html(jQuery(this).attr("pword"))}, {close:"Close"});
    });    
});
</script>