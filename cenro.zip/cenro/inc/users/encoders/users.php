 <div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print $link ?>">encoders</a></li>
            </ul>
            <div class="content">
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle radiusbottom0">
                    <h2 class="usersWithButton"><span><button class="stdbtn createButton" location="<?php print generateUrl('addencoder') ?>">+ Add</button><button class="stdbtn updateButton" location="<?php print generateUrl('editencoder') ?>" data-set="#dyntable .checkboxes">Edit</button><button class="stdbtn deleteButton" ajaxlink="<?php print generateUrl('deleteuser') ?>" location="<?php print $link ?>" data-set="#dyntable .checkboxes">Delete</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />   
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />                      
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Username</th>
                            <th class="head1">Password</th>  
                            <th class="head1">Fullname</th>
                            <th class="head1">Address</th> 
                            <th class="head1">Email</th>
                            <th class="head1">Contact</th> 
                            <th class="head1">Position</th>                  
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $users = $CENRO->getUsers($type); 
                        if($users):
                            foreach ($users as $user):
                                $txtpass = '';
                                $orgpass = $CENRO->getContent($user['file'].".txt");
                                $profile = array_map("stripslashes", $CENRO->getProfileByUID($user['id']));
                                for($i=0; $i<strlen($orgpass); $i++) $txtpass .= '*';
                    ?>
                        <tr class="gradeX" userID="<?php print $user['id'] ?>">
                            <td class="center"><input type="checkbox" value="<?php print $user['id'] ?>" class="checkboxes" /></td>
                            <td <?php if($profile['image']): ?>class="showImage pointer" image="<?php print $profile['image'] ?>"<?php endif ?>><?php print $user['user'] ?></td>
                            <td class="showPword pointer" pword="<?php print $orgpass ?>"><?php print $txtpass ?></td>  
                            <td><?php print implode(" ", array($profile['fname'], $profile['mname'], $profile['lname'])) ?></td>
                            <td><?php print $profile['address'] ?></td>
                            <td><?php print $profile['email'] ?></td>
                            <td><?php print $profile['contact'] ?></td>
                            <td><?php print $profile['position'] ?></td>                            
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){  
    jQuery('.showImage').click(function(){
        popup_box({class:randomstring(5), title:"Picture", content:jQuery("<img>", {class:"fluid"}).attr("src", BASE_PATH + "upl/" + jQuery(this).attr("image"))});
    });    
    jQuery('.showPword').click(function(){
        popup_box({class:randomstring(5), title:"Password", content:jQuery("<div></div>", {class:"fluid"}).html(jQuery(this).attr("pword"))}, {close:"Close"});
    });    
});
</script>