<div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print $action ?>">validators</a></li>
            </ul>
            <div class="content">
                <div class="contenttitle">
                    <h2 class="form"><span>edit validator</span></h2>
                </div>
                <form id="form2" class="stdform stdform2" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="profile_id" value="<?php print $profile_id ?>" />
                    <input type="hidden" name="image" value="<?php print $image ?>" />
                    <p>
                        <label>Last Name</label>
                        <span class="field"><input type="text" name="lname" class="smallinput <?php print $filter ?>" value="<?php print $lname ?>" /></span>
                    </p>
                    <p>
                        <label>First Name</label>
                        <span class="field"><input type="text" name="fname" class="smallinput <?php print $filter ?>" value="<?php print $fname ?>" /></span>
                    </p>
                    <p>
                        <label>Middle Name</label>
                        <span class="field"><input type="text" name="mname" class="smallinput <?php print $filter ?>" value="<?php print $mname ?>" /></span>
                    </p>                    
                    <p>
                        <label>Email <small style="position:absolute">Email address, yahoo or gmail.</small></label>
                        <span class="field"><input type="text" name="email" class="smallinput <?php print $filter ?>" value="<?php print $email ?>" /></span>
                    </p>
                    <p>
                        <label>Contact <small style="position:absolute">Cellphone or Telephone number.</small></label>
                        <span class="field"><input type="text" name="contact" class="smallinput integer <?php print $filter ?>" maxlength="11" value="<?php print $contact ?>" /></span>
                    </p>
                    <p>
                        <label>Address <small style="position:absolute">Permanent address.</small></label>
                        <span class="field"><textarea cols="80" rows="5" name="address" class="smallinput <?php print $filter ?>"><?php print $address ?></textarea></span>
                    </p> 
                    <p>
                        <label>Position</label>
                        <span class="field"><input type="text" name="position" class="smallinput <?php print $filter ?>" value="<?php print $position ?>" /></span>
                    </p>
                    <p>
                        <label>Picture</label>
                        <span class="field">
                            <input type="file" name="image" class="smallinput" accept="image/*" />
                        </span>
                    </p>
                    <p>
                        <label>Program</label>
                        <span class="field">
                            <select class="smallinput <?php print $filter ?>" name="pid">
                            <?php foreach(getPrograms() as $key => $val): ?>
                                <option value="<?php print $key ?>" <?php if($key==$program_id) print "SELECTED" ?>><?php print $val ?></option>
                            <?php endforeach ?>
                            </select>
                        </span>
                    </p>
                    <p>
                        <label>Username</label>
                        <span class="field"><input name="username" class="smallinput <?php print $filter ?>" value="<?php print $username ?>" type="text" /></span>
                    </p>
                    <p>
                        <label>Password</label>
                        <span class="field"><input name="password" class="smallinput <?php print $filter ?>" value="<?php print $password ?>" type="password" /></span>
                    </p>
                    <p class="stdformbutton">
                        <button name="update" class="submit radius2 submitButton" onclick="return filterInput('<?php print $filter ?>')">Save</button>
                        <input type="reset" class="reset radius2 returnButton" value="Cancel" location="<?php print $action ?>" />
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){ 
    jQuery("input[name='lname'], input[name='fname'], input[name='mname']").filter_input({regex:"[a-z A-Z]"});
});
</script>