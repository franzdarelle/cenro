<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">  
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl('complaints') ?>">complaints</a></li>
            </ul>
            <div class="content">              
                <div class="contenttitle radiusbottom0">
                    <h2 class="complaintsWithButton"><span><button class="stdbtn deleteButton" ajaxlink="<?php print generateUrl('deletecomplaint') ?>" location="<?php print generateUrl('complaints') ?>" data-set="#dyntable .checkboxes">Delete</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />             
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Name</th>                            
                            <th class="head1">Message</th>
                            <th class="head1" style="width:150px">Date</th>            
                        </tr>
                    </thead>
                    <tbody>
                    <?php      
                        $complaints = $CENRO->getComplaints();                  
                        if($complaints): 
                            foreach($complaints as $c):
                                $message = stripslashes($c['message']);
                    ?>
                        <tr class="gradeX pointer">
                            <td class="center"><input type="checkbox" value="<?php print $c['id'] ?>" class="checkboxes" /></td>
                            <td><?php print $c['name']? stripslashes($c['name']) : 'Anonymous' ?></td>                                                        
                            <td><?php print (strlen($message) > 100) ? substr($message, 0, 100) . "..." : $message ?></td>
                            <td class="center"><?php print date("Y/m/d H:i:s A", strtotime($c['date'])) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<div id="complaintDetails" class="fluid">    
    <div id="name"></div>
    <div id="date"></div>
    <div><img class="fluid" /></div>
    <div id="text"></div>
</div>
<script type="text/javascript">
var complaintDetails = jQuery("div#complaintDetails").hide();
complaintDetails.find("#name").css({"padding-bottom":5, "font-weight":"bold"});
complaintDetails.find("#date").css({"padding-bottom":5});
complaintDetails.find("#text").css({"padding-bottom":5,"padding-top":5});

jQuery("tr").dblclick(function(){
    var id = jQuery(this).find("input").val();
    jQuery.getJSON(BASE_PATH + "jsoncomplaint/" + id, function(json) {    
        if(json.photo.length) complaintDetails.find("img").attr("src", BASE_PATH + "upl/" + json.photo);     
        else {
            complaintDetails.find("img").removeAttr("src");
        }
        complaintDetails.find("#name").empty().append(json.name);
        complaintDetails.find("#date").empty().append(json.date);        
        complaintDetails.find("#text").empty().append(json.message);
        popup_box({class:randomstring(5), width:500, height:500, place:true, title:"Complaint", content:complaintDetails.show()}, {close:"Close"});
    });
});
</script>