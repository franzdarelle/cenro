<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <?php
            $programs = getPrograms();
            $services = $CENRO->getServices($pid);
        ?>
        <ul class="breadcrumbs">
            <li><?php print $programs[$pid] ?></li>
        </ul>
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl(implode("/", array('services', $pid))) ?>">services</a></li>
            </ul>
            <div class="content">
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle radiusbottom0">
                    <h2 class="typesWithButton"><span><button class="stdbtn createButton" location="<?php print generateUrl(implode("/", array('addservice', $pid))) ?>">+ Add</button><button class="stdbtn updateButton" location="<?php print generateUrl(implode("/", array("editservice", $pid))) ?>" data-set="#dyntable .checkboxes">Edit</button><button class="stdbtn deleteButton" ajaxlink="<?php print generateUrl('deleteservice') ?>" location="<?php print generateUrl(implode("/", array("services", $pid))) ?>" data-set="#dyntable .checkboxes">Delete</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Name</th>
                            <th class="head1">Description</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php                        
                        if($services): 
                            foreach($services as $service):
                    ?>
                        <tr class="gradeX pointer">
                            <td class="center"><input type="checkbox" value="<?php print $service['id'] ?>" class="checkboxes" /></td>
                            <td><?php print stripslashes($service['name']) ?></td>                            
                            <td><?php print stripslashes($service['description']) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(".breadcrumbs").css({"margin-bottom":10}).find("li").css({"padding":"5px 20px 5px 10px","color":"#333"});
jQuery("tr").dblclick(function(){
    jQuery(location).attr("href", "<?php print generateUrl('requirements') ?>/" + jQuery(this).find("input").val());
});
</script>