<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl('programs') ?>">programs</a></li>
            </ul>
            <div class="content">          
                <div class="contenttitle radiusbottom0">
                    <h2 class="types"><span>programs</span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <tbody>
                    <?php foreach (getPrograms() as $key => $val): ?>
                        <tr class="gradeX pointer" id="<?php print $key ?>">   
                            <td><?php print $val ?></td>
                        </tr>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){ 
    jQuery("tr").click(function(){
        jQuery(location).attr("href", "<?php print generateUrl('services') ?>/" + jQuery(this).attr("id"));
    });
});
</script>