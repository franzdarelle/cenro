<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <?php
            $programs = getPrograms();
            $service = array_map("stripslashes", $CENRO->getService($sid));
            $requirements = $CENRO->getRequirements($sid);
        ?>
        <ul class="breadcrumbs">
            <li><a href="<?php print generateUrl(implode("/", array('services', $service['pid']))) ?>"><?php print $programs[$service['pid']] ?></a></li> 
            <li><?php print $service['name'] ?></li>
        </ul>
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl(implode("/", array('requirements', $sid))) ?>">requirements</a></li>
            </ul>
            <div class="content">
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle radiusbottom0">
                    <h2 class="typesWithButton"><span><button class="stdbtn createButton" location="<?php print generateUrl(implode("/", array('addrequirement', $sid))) ?>">+ Add</button><button class="stdbtn updateButton" location="<?php print generateUrl(implode("/", array("editrequirement", $sid))) ?>" data-set="#dyntable .checkboxes">Edit</button><button class="stdbtn deleteButton" ajaxlink="<?php print generateUrl('deleterequirement') ?>" location="<?php print generateUrl(implode("/", array("requirements", $sid))) ?>" data-set="#dyntable .checkboxes">Delete</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Name</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php                        
                        if($requirements): 
                            foreach($requirements as $requirement):
                    ?>
                        <tr class="gradeX pointer">
                            <td class="center"><input type="checkbox" value="<?php print $requirement['id'] ?>" class="checkboxes" /></td>
                            <td><?php print stripslashes($requirement['name']) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">jQuery(".breadcrumbs").css({"margin-bottom":10}).find("a").css({"color":"#6CA429"})</script>