<div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <ul class="breadcrumbs">
            <li><a href="<?php print generateUrl(implode("/", array('services', $pid))) ?>"><?php print $program ?></a></li> 
            <li><a href="<?php print $action ?>"><?php print $service ?></a></li>
            <li>Add Requirement</li>
        </ul>
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print $action ?>"><?php print $service ?></a></li>
            </ul>
            <div class="content">
                <div class="contenttitle">
                    <h2 class="form"><span>add requirement</span></h2>
                </div>
                <form id="form2" class="stdform stdform2" method="post" action="#">
                    <p>
                        <label>Name</label>
                        <span class="field"><input type="text" name="name" class="longinput <?php print $filter ?>" /></span>
                    </p>   
                    <p class="stdformbutton">
                        <button name="create" class="submit radius2 submitButton" onclick="return filterInput('<?php print $filter ?>')">Save</button>
                        <input type="reset" class="reset radius2 returnButton" value="Cancel" location="<?php print $action ?>" />
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">jQuery(".breadcrumbs").css({"margin-bottom":10}).find("a").css({"color":"#6CA429"})</script>