<style type="text/css">
@page { margin: 25px 15px 0px 15px }
#paper {
	width: 100%;
	margin: 5px;
	text-align: center;
}
table { width: 100% }
.center { text-align: center }
.right { text-align: right }
.bold { font-weight: bold }
th.data, td.data { border: 1px solid #000 }
td.data { padding: 2px 5px }
th { background-color: #79B82E }
td { font-size: 12px }
</style>
<div id="paper">
	<table class="page">
		<tr class="center bold">
			<td style="font-size:16px">VIOLATED APPLICATIONS</td>
		</tr>
		<tr class="center">
			<td style="font-size:12px"><?php print date("F Y") ?></td>
		</tr>
		<tr class="center">
			<td>
				<table cellspacing="0">		 
					<tr class="center">
						<th class="data">#</th>
						<th class="data">PROGRAM</th>
                        <th class="data">SERVICE</th> 
                        <th class="data">COMPANY</th>
                        <th class="data">ADDRESS</th>
                        <th class="data">APPLICANT</th>
                        <th class="data">SUBMITTED</th> 
                        <th class="data">VIOLATION</th>                        
					</tr>	
					<?php
						$programs = getPrograms();
	                    $applications = $CENRO->getApplicationsWithViolationsThisMonth(date("m"), date("Y"));
                        if($applications):
                        	$count = 1;
                            foreach($applications as $apps):                                         
                                $d = array_map("stripslashes", $apps);
                    ?>				
	                    <tr>    
	                    	<td class="data center"><?php print $count ?></td>                                
	                        <td class="data"><?php print $programs[$d['pid']] ?></td> 
	                        <td class="data"><?php print stripslashes($d['service']) ?></td>  
	                        <td class="data"><?php print stripslashes($d['company']) ?></td>
	                        <td class="data"><?php print stripslashes($d['address']) ?></td>
	                        <td class="data"><?php print stripslashes(implode(" ", array($d['fname'], $d['mname'], $d['lname']))) ?></td>
	                        <td class="data"><?php print date("F j, Y", strtotime($d['created'])) ?></td>
	                        <td class="data">
	                        <?php 
	                        	$dViolations = json_decode($d['violations']);
	                        	$aViolations = array();
	                        	foreach ($dViolations as $v) {
	                        		$violation = $CENRO->getViolation($v);
	                        		$aViolations[] = stripslashes($violation['name']);
	                        	}
	                        	print implode(", ", $aViolations);
	                        ?>
	                        </td>                                                    
	                    </tr>
	                <?php $count++; endforeach; endif ?>
				</table>
			</td>
		</tr>
	</table>
</div>