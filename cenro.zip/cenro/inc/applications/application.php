<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <?php
            $programs = getPrograms();
            $recommendations = getRecommendations();
            switch ($apps['status']) {
                case 0:
                case 1;
                    $status = "pending";
                break;
                default:
                    $status = "approved";
                break;
            }
        ?>
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl('application') ?>"><?php print $status ?></a></li>
            </ul>
            <div class="content"> 
                <div class="contenttitle radiusbottom0">
                    <h2 class="items"><span><?php print $programs[$apps['pid']] ?></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <colgroup>            
                        <col class="con1" /> 
                        <col class="con0" />
                    </colgroup> 
                    <tbody>
                        <tr>    
                            <td class="border strong">Service</td>
                            <td class="border"><?php print stripslashes($apps['service']) ?></td>
                        </tr>
                        <tr>    
                            <td class="strong">Company</td>
                            <td><?php print stripslashes($apps['company']) ?></td>
                        </tr> 
                        <tr>    
                            <td class="strong">Address</td>
                            <td><?php print stripslashes($apps['address']) ?></td>
                        </tr>
                        <tr>    
                            <td class="strong">Applicant</td>
                            <td><?php print implode(" ", array($apps['fname'], $apps['mname'], $apps['lname'])) ?></td>
                        </tr>
                        <tr>    
                            <td class="strong">Created</td>
                            <td><?php print date("Y/m/d H:i:s A", strtotime($apps['created'])) ?></td>
                        </tr>
                        <tr>    
                            <td class="strong">Updated</td>
                            <td><?php print date("Y/m/d H:i:s A", strtotime($apps['updated'])) ?></td>
                        </tr>
                        <tr>    
                            <td class="strong">Status</td>
                            <td><?php print ucfirst($status) ?></td>
                        </tr>
                        <?php
                            $ufRequirements = json_decode($apps['requirements']);
                            $dbRequirements = $CENRO->getRequirements($apps['sid']);   
                            foreach ($dbRequirements as $r):  
                                $id = $r['id'];
                                if(isset($ufRequirements->$id)) {
                                    $pdf_file = getUPLFileLink($ufRequirements->$id->pdf_file);
                                    $approved = $ufRequirements->$id->approved;
                                } else {
                                    $pdf_file = null;
                                    $approved = null;
                                }                 
                        ?>         
                        <tr>    
                            <td class="strong"><?php print stripslashes($r['name']) ?></td>
                            <td>
                                <?php print $pdf_file ?>
                                <span style="float:right">
                                    <span style="border:1px solid #ddd; display:inline-block">
                                        <img src="<?php print baseURL() . 'images/' . ($approved? 'btn2.png' : 'btn1.png') ?>">
                                    </span>
                                </span>
                            </td>
                        </tr>  
                        <?php endforeach ?>
                        <?php 
                            if($apps['violations']):
                                $violations = json_decode($apps['violations']);                                
                        ?>
                        <tr>    
                            <td class="strong" colspan="2">Violations</td>
                        </tr> 
                        <?php foreach ($violations as $v): $violation = $CENRO->getViolation($v); ?>
                        <tr class="violations">    
                            <td><?php print stripslashes($violation['name']) ?></td>
                            <td><?php print stripslashes($violation['description']) ?></td>
                        </tr> 
                        <?php endforeach; endif ?>
                        <tr>    
                            <td class="strong">Remarks</td>
                            <td><?php print stripslashes($apps['remarks']) ?></td>
                        </tr>  
                        <?php if($apps['recommendation']): ?>
                        <tr>    
                            <td class="strong">Recommendation</td>
                            <td><?php print $recommendations[$apps['recommendation']] ?></td>
                        </tr> 
                        <tr>    
                            <td class="strong alignRight">On</td>
                            <td><?php print $apps['actionOn'] ?></td>
                        </tr>
                        <tr>    
                            <td class="strong alignRight">By</td>
                            <td><?php print $apps['actionBy'] ?></td>
                        </tr> 
                        <?php endif ?>        
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("table.stdtable td.border").css({"border-top":"1px solid #ddd"});
    jQuery(".violations").css({"background":"#fff"});
});
</script>