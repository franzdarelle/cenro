<?php $status = getArgument(2) ?>
<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl(implode("/", array('applications', $status))) ?>"><?php print $status ?></a></li>
            </ul>
            <div class="content">      
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle radiusbottom0">
                    <h2 class="itemsWithButton"><span><button class="stdbtn deleteButton" ajaxlink="<?php print generateUrl('deleteapplication') ?>" location="<?php print generateUrl(implode("/", array('applications', $status))) ?>" data-set="#dyntable .checkboxes">Delete</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Program</th>
                            <th class="head1">Service</th>
                            <th class="head1">Company</th>
                            <th class="head1">Address</th>
                            <th class="head1">Applicant</th>
                            <th class="head1">Created</th>
                            <th class="head1">Updated</th>
                            <th class="head1">Encoder</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $programs = getPrograms();
                        $applications = $CENRO->getApplicationsByStatus((($status=='pending')? 0 : 1), $CENRO->getValidatorPID($CENRO->access->getUser()));               
                        if($applications): 
                            foreach($applications as $application):
                                $user = $CENRO->getUser($application['uid']);
                    ?>
                        <tr class="gradeX pointer">
                            <td class="center"><input type="checkbox" value="<?php print $application['id'] ?>" class="checkboxes" /></td>
                            <td><?php print $programs[$application['pid']] ?></td>
                            <td><?php print stripslashes($application['service']) ?></td>
                            <td><?php print stripslashes($application['company']) ?></td>                            
                            <td><?php print stripslashes($application['address']) ?></td>
                            <td><?php print stripslashes(implode(" ", array($application['fname'], $application['mname'], $application['lname']))) ?></td>
                            <td class="center"><?php print date("Y/m/d H:i:s A", strtotime($application['created'])) ?></td>
                            <td class="center"><?php print date("Y/m/d H:i:s A", strtotime($application['updated'])) ?></td>
                            <td class="center"><?php print $user['user'] ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<div id="applicationDetails" class="fluid">
    <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
        <colgroup>            
            <col class="con1" /> 
            <col class="con0" />
        </colgroup> 
        <tbody>
            <tr>    
                <td class="border strong">Program</td>
                <td class="border" id="program"></td>
            </tr>
            <tr>    
                <td class="strong">Service</td>
                <td id="service"></td>
            </tr> 
            <tr>    
                <td class="strong">Company</td>
                <td id="company"></td>
            </tr>
            <tr>    
                <td class="strong">Address</td>
                <td id="address"></td>
            </tr>
            <tr>    
                <td class="strong">Applicant</td>
                <td id="appicant"></td>
            </tr>
            <tr>    
                <td class="strong">Created</td>
                <td id="created"></td>
            </tr>
            <tr>    
                <td class="strong">Updated</td>
                <td id="updated"></td>
            </tr>
            <tr>    
                <td class="strong">Status</td>
                <td id="status"></td>
            </tr>
            <tr id="violations">    
                <td class="strong" colspan="2">
                    Violations
                    <span style="float: right;" class="center"><span id="addViolation" style="border: 1px solid rgb(221, 221, 221); display: inline-block; background: rgb(255, 255, 255) none repeat scroll 0% 0%;" class="pointer"><img src="<?php print baseURL() ?>images/btn3.png"></span></span>
                </td>           
            </tr>            
            <tr>    
                <td class="strong">Remarks</td>
                <td style="padding:5px 6px 5px 5px"><textarea id="remarks" style="width:95%"></textarea></td>
            </tr>
            <tr id="recommendation">    
                <td class="strong">Recommendation</td>
                <td style="padding:5px 6px 5px 5px">
                    <select style="width:100%">
                    <?php foreach (getRecommendations() as $key => $val): ?>
                        <option value="<?php print $key ?>"><?php print $val ?></option>
                    <?php endforeach ?>
                    </select>
                </td>
            </tr>
            <tr class="actions">    
                <td class="strong alignRight">On</td>
                <td style="padding:5px 6px 5px 5px"><input type="text" id="actionOn" /></td>
            </tr>
            <tr class="actions">    
                <td class="strong alignRight">By</td>
                <td style="padding:5px 6px 5px 5px"><input type="text" id="actionBy" /></td>
            </tr>
        </tbody>
    </table>   
    <div class="popup_buttons"><input id="verify" value="Verify" class="popup_triggers" type="button"></div> 
</div>
<link rel="stylesheet" href="<?php echo baseUrl() ?>css/datepicker.css" type="text/css" />
<script type="text/javascript">
jQuery("div.popup_buttons").css({"border":"1px solid #ddd","border-top":0});
jQuery("div#applicationDetails td.border").css({"border-top":"1px solid #ddd"});
var applicationDetails = jQuery("div#applicationDetails").hide();
jQuery("table.stdtable tr").dblclick(function(){
    var id = jQuery(this).find("td").first().find("input").val();
    jQuery.getJSON(BASE_PATH + "jsonapplication/" + id, function(json) { 
        var status = (parseInt(json.status)==0)? "Pending" : "Verified";
        applicationDetails.find("#program").empty().html(json.program);
        applicationDetails.find("#service").empty().html(json.service);        
        applicationDetails.find("#company").empty().html(json.company);
        applicationDetails.find("#address").empty().html(json.address);
        applicationDetails.find("#appicant").empty().html(json.fname + " " + json.mname + " " + json.lname);     
        applicationDetails.find("#status").empty().html(status);
        applicationDetails.find("#created").empty().html(json.created);
        applicationDetails.find("#updated").empty().html(json.updated);
        applicationDetails.find("#remarks").empty().html(json.remarks).change(function(){
            jQuery.ajax({
                url: "<?php print generateUrl('remarksapplication') ?>",
                type: "POST",
                data: {id:id, remarks:jQuery(this).val()},
                dataType:"html"
            });
        }).css({"border":"1px solid #ddd", "padding":5});
        applicationDetails.find("#verify").click(function(){
            if(confirm("Verify application?")) {
                jQuery.ajax({
                    url: "<?php print generateUrl('verifyapplication') ?>",
                    type: "POST",
                    data: {id:id},
                    dataType:"html"
                }).done(function(e){
                    jQuery(location).attr("href", window.location);
                });
            }            
        });
        applicationDetails.find("select").find('option').each(function(){
            if(jQuery(this).attr('value')==json.recommendation) jQuery(this).attr('selected','selected');            
        });
        applicationDetails.find("select").change(function(){
            jQuery.ajax({
                url: "<?php print generateUrl('recommendationapplication') ?>",
                type: "POST",
                data: {id:id, recommendation:jQuery(this).val()},
                dataType:"html"
            });
        });
        applicationDetails.find("#actionOn, #actionBy").css({"border":"1px solid #ddd", "padding":5, "width":"95%"});     
        applicationDetails.find("#actionOn").removeClass("hasDatepicker").datepicker().val(json.actionOn);
        applicationDetails.find("#actionBy").val(json.actionBy);
        applicationDetails.find("#actionOn").change(function(){
            jQuery.ajax({
                url: "<?php print generateUrl('actionOnapplication') ?>",
                type: "POST",
                data: {id:id, actionOn:jQuery(this).val()},
                dataType:"html"
            });
        });
        applicationDetails.find("#actionBy").change(function(){
            jQuery.ajax({
                url: "<?php print generateUrl('actionByapplication') ?>",
                type: "POST",
                data: {id:id, actionBy:jQuery(this).val()},
                dataType:"html"
            });
        });
        applicationDetails.find(".pdffile, .violations, .history").remove();
        applicationDetails.find("#recommendation, .actions").hide();
        applicationDetails.find("#addViolation").click(function(){
            if(confirm("Add violation?")) {
                var tr = jQuery("<tr></tr>", {class:"violations"});
                var td = jQuery("<td></td>", {"colspan":2}).css({"background":"#fff"});  
                var sv = jQuery("<select></select>", {class:"vids"}).css({"border":"1px solid #ddd"});
                sv.change(function(){
                    var vids = new Array;
                    applicationDetails.find("select.vids").each(function(){
                        vids.push(jQuery(this).val());
                    });    
                    jQuery.ajax({
                        url: "<?php print generateUrl('violationapplication') ?>",
                        type: "POST",
                        data: {id:id, vids:vids},
                        dataType:"html"
                    });
                });             

                jQuery.getJSON(BASE_PATH + "jsonviolations", function(json) { 
                    jQuery.each(json, function(i,v) {
                        sv.append(jQuery("<option></option>", {"value":v.id}).html(v.name));
                    });
                    sv.trigger("change");
                });

                var img = jQuery("<img>", {"src":BASE_PATH + 'images/btn1.png'});
                var btn = jQuery("<span></span>", {class:"pointer"}).css({"border":"1px solid #ddd","display":"inline-block"}).append(img);
                var div = jQuery("<span></span>", {class:"center"}).css({"float":"right"}).append(btn);
                div.click(function(){                    
                    var row = jQuery(this).parents("tr");
                    var vid = row.find("select").val();
                    row.remove();
                    jQuery.ajax({
                        url: "<?php print generateUrl('historyapplication') ?>",
                        type: "POST",
                        data: {id:id, vid:vid},
                        dataType:"html"
                    }).done(function(violation){
                        var vids = new Array;
                        applicationDetails.find("select.vids").each(function(){
                            vids.push(jQuery(this).val());
                        });    
                        jQuery.ajax({
                            url: "<?php print generateUrl('violationapplication') ?>",
                            type: "POST",
                            data: {id:id, vids:vids},
                            dataType:"html"
                        }).done(function(e){
                            if(vids.length==0) {
                                jQuery.ajax({
                                    url: "<?php print generateUrl('jsoncountverifiedpdf') ?>",
                                    type: "POST",
                                    data: {id:id},
                                    dataType:"html"
                                }).done(function(e){
                                    var r = jQuery.parseJSON(e);
                                    if(r.pdffiles==r.approved) {
                                        applicationDetails.find("#recommendation, .actions, div.popup_buttons").show();                             
                                    } else {
                                        applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();                             
                                    }
                                });       
                            }
                        });

                        var tr = jQuery("<tr></tr>", {class:"history"});
                        var td = jQuery("<td></td>", {"colspan":2}).css({"background":"#fff"});
                        td.append(violation);
                        tr.append(td);
                        if(applicationDetails.find(".history").length) tr.insertBefore(applicationDetails.find(".history").first());
                        else {
                            tr.insertAfter(applicationDetails.find(".violations").length? applicationDetails.find(".violations").last() : applicationDetails.find("#violations")); 
                        }                        
                    });
                });

                td.append(sv).append(div);
                tr.append(td);
                tr.insertAfter(jQuery(this).parents("tr")); 

                jQuery.ajax({
                    url: "<?php print generateUrl('disapproveapplication') ?>",
                    type: "POST",
                    data: {id:id},
                    dataType:"html"
                }).done(function(e){
                    applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();               
                });
            }
        });
        
        var pdffiles = 0;
        var approved = 0;

        jQuery.each(json.pdffile, function(i,v){
            var img1 = jQuery("<img>", {"src":BASE_PATH + 'images/btn1.png'});
            var img2 = jQuery("<img>", {"src":BASE_PATH + 'images/btn2.png'});
            var btn1 = jQuery("<span></span>", {class:"pointer"}).css({"border":"1px solid #ddd","display":"inline-block","background":"#eee"}).append(img1);
            var btn2 = jQuery("<span></span>", {class:"pointer"}).css({"border":"1px solid #ddd","display":"inline-block","background":"#eee"}).append(img2);
            btn1.click(function(){
                jQuery.ajax({
                    url: "<?php print generateUrl('verifypdffile') ?>",
                    type: "POST",
                    data: {aid:id, rid:i, val:0},
                    dataType:"html"
                }).done(function(e){  
                    var r = jQuery.parseJSON(e);
                    if(r.verified) {
                        btn1.css({"background":"#fff"});
                        btn2.css({"background":"#eee"});
                        applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();    
                        jQuery.ajax({
                            url: "<?php print generateUrl('recommendationapplication') ?>",
                            type: "POST",
                            data: {id:id, recommendation:0},
                            dataType:"html"
                        });
                    }                     
                });
            });
            btn2.click(function(){
                jQuery.ajax({
                    url: "<?php print generateUrl('verifypdffile') ?>",
                    type: "POST",
                    data: {aid:id, rid:i, val:1},
                    dataType:"html"
                }).done(function(e){ 
                    var r = jQuery.parseJSON(e);
                    if(r.verified) {
                        btn1.css({"background":"#eee"});
                        btn2.css({"background":"#fff"});                        
                        if(r.approved==r.pdffiles) {
                            if(applicationDetails.find(".violations").length) {
                                applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();                 
                            } else {
                                applicationDetails.find("#recommendation, .actions, div.popup_buttons").show().find("select").trigger("change");                                
                            }                            
                        } else {
                            applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();
                        }
                    }                    
                });
            });
            var div = jQuery("<span></span>", {class:"center"}).css({"float":"right"}).append(btn1).append(btn2);    
            var row = jQuery("<tr></tr>", {class:"pdffile"});
            var td1 = jQuery("<td></td>", {class:"strong"}).html(v.file_for);
            var td2 = jQuery("<td></td>").html(v.pdf_file).append(div);
            row.append(td1).append(td2).insertBefore(applicationDetails.find("#violations")); 
            if(v.pdf_file.length==0) {
                btn1.unbind("click").removeClass("pointer");
                btn2.unbind("click").removeClass("pointer");
            }           
            if(v.approved==0) btn1.css({"background":"#fff"}) 
            else {
                btn2.css({"background":"#fff"});
                approved++;
            }
            if(status=="Verified") {
                btn1.unbind("click").removeClass("pointer");
                btn2.unbind("click").removeClass("pointer");                
                applicationDetails.find("#remarks, #actionOn, #actionBy").attr("readonly","readonly");                
                applicationDetails.find("select option:not(:selected)").attr("disabled","disabled");          
            }
            pdffiles++;
        });

        if(json.violations.length) {            
            var violations = jQuery.parseJSON(json.violations);            
            jQuery.each(violations, function(i,violation_id){
                var tr = jQuery("<tr></tr>", {class:"violations"});
                var td = jQuery("<td></td>", {"colspan":2}).css({"background":"#fff"});  
                var sv = jQuery("<select></select>", {class:"vids"}).css({"border":"1px solid #ddd"});
                sv.change(function(){
                    var vids = new Array;
                    applicationDetails.find("select.vids").each(function(){
                        vids.push(jQuery(this).val());
                    });    
                    jQuery.ajax({
                        url: "<?php print generateUrl('violationapplication') ?>",
                        type: "POST",
                        data: {id:id, vids:vids},
                        dataType:"html"
                    });
                });             

                jQuery.getJSON(BASE_PATH + "jsonviolations", function(json) { 
                    jQuery.each(json, function(i,v) {
                        if(v.id==violation_id) {
                            sv.append(jQuery("<option></option>", {"value":v.id,"selected":"selected"}).html(v.name));
                        } else {
                            sv.append(jQuery("<option></option>", {"value":v.id}).html(v.name));
                        }
                    });
                });

                var img = jQuery("<img>", {"src":BASE_PATH + 'images/btn1.png'});
                var btn = jQuery("<span></span>", {class:"pointer"}).css({"border":"1px solid #ddd","display":"inline-block"}).append(img);
                var div = jQuery("<span></span>", {class:"center"}).css({"float":"right"}).append(btn);
                div.click(function(){                    
                    var row = jQuery(this).parents("tr");
                    var vid = row.find("select").val();
                    row.remove();

                    jQuery.ajax({
                        url: "<?php print generateUrl('historyapplication') ?>",
                        type: "POST",
                        data: {id:id, vid:vid},
                        dataType:"html"
                    }).done(function(violation){                        
                        var vids = new Array;
                        applicationDetails.find("select.vids").each(function(){
                            vids.push(jQuery(this).val());
                        });    
                        jQuery.ajax({
                            url: "<?php print generateUrl('violationapplication') ?>",
                            type: "POST",
                            data: {id:id, vids:vids},
                            dataType:"html"
                        }).done(function(e){
                            if(vids.length==0) {
                                jQuery.ajax({
                                    url: "<?php print generateUrl('jsoncountverifiedpdf') ?>",
                                    type: "POST",
                                    data: {id:id},
                                    dataType:"html"
                                }).done(function(e){
                                    var r = jQuery.parseJSON(e);
                                    if(r.pdffiles==r.approved) {
                                        applicationDetails.find("#recommendation, .actions, div.popup_buttons").show();                            
                                    } else {
                                        applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();                                    
                                    }
                                });       
                            }
                        });

                        var tr = jQuery("<tr></tr>", {class:"history"});
                        var td = jQuery("<td></td>", {"colspan":2}).css({"background":"#fff"});
                        td.append(violation);
                        tr.append(td);
                        if(applicationDetails.find(".history").length) tr.insertBefore(applicationDetails.find(".history").first());
                        else {
                            tr.insertAfter(applicationDetails.find(".violations").length? applicationDetails.find(".violations").last() : applicationDetails.find("#violations")); 
                        }                        
                    });                    
                });

                td.append(sv).append(div);
                tr.append(td);
                tr.insertAfter(applicationDetails.find(".violations").length? applicationDetails.find(".violations").last() : applicationDetails.find("#violations")); 
            });  
        }

        if(json.history.length) {
            var history = jQuery.parseJSON(json.history);
            jQuery.each(history, function(i,violation_id){
                var tr = jQuery("<tr></tr>", {class:"history"});
                var td = jQuery("<td></td>", {"colspan":2}).css({"background":"#fff"});  

                jQuery.getJSON(BASE_PATH + "jsonviolations", function(json) { 
                    jQuery.each(json, function(i,v) {
                        if(v.id==violation_id) {
                            td.append(v.name);
                        }
                    });
                });

                tr.append(td);
                if(applicationDetails.find(".history").length) tr.insertBefore(applicationDetails.find(".history").first());
                else {
                    tr.insertAfter(applicationDetails.find(".violations").length? applicationDetails.find(".violations").last() : applicationDetails.find("#violations")); 
                }
            });
        }

        if(approved==pdffiles) {
            applicationDetails.find("#recommendation, .actions").show();
            if(status=="Pending") {
                applicationDetails.find("div.popup_buttons").show();
            } else {
                applicationDetails.find("div.popup_buttons").hide();
            }
        } else {
            applicationDetails.find("div.popup_buttons").hide();
        }

        if(applicationDetails.find(".violations").length) {
            applicationDetails.find("#recommendation, .actions, div.popup_buttons").hide();            
        }

        popup_box({class:randomstring(5), width:500, height:500, place:true, title:"Application", content:applicationDetails.show()}, {close:false});
    });    
});

var deletable = <?php print ($status=="pending")? "true" : "false" ?>;
if (deletable) {
    jQuery(".deleteButton").removeAttr("disabled");
} else {
    jQuery(".deleteButton").attr("disabled","disabled");
}
</script>