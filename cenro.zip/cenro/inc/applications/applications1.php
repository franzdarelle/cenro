<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl('applications') ?>">applications</a></li>
            </ul>
            <div class="content">
                <?php if(isset($_SESSION[$CENRO->warning])): ?>
                <div class="notification msgalert">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->warning] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->warning]); endif ?>
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle radiusbottom0">
                    <h2 class="itemsWithButton"><span><button class="stdbtn createButton" location="<?php print generateUrl('addapplication') ?>">+ Add</button><button class="stdbtn updateButton" location="<?php print generateUrl('editapplication') ?>" data-set="#dyntable .checkboxes">Edit</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Program</th>
                            <th class="head1">Service</th>
                            <th class="head1">Company</th>
                            <th class="head1">Address</th>
                            <th class="head1">Fullname</th>                     
                            <th class="head1">Created</th>
                            <th class="head1">Updated</th>
                            <th class="head1">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $programs = getPrograms();
                        $applications = $CENRO->getApplications($CENRO->access->getUser());
                        if($applications): 
                            foreach($applications as $application):
                    ?>
                        <tr class="gradeX pointer">
                            <td class="center"><input type="checkbox" value="<?php print $application['id'] ?>" class="checkboxes" /></td>
                            <td><?php print $programs[$application['pid']] ?></td>
                            <td><?php print stripslashes($application['service']) ?></td>
                            <td><?php print stripslashes($application['company']) ?></td>                            
                            <td><?php print stripslashes($application['address']) ?></td>
                            <td><?php print stripslashes(implode(" ", array($application['fname'], $application['mname'], $application['lname']))) ?></td> 
                            <td class="center"><?php print date("Y/m/d H:i:s A", strtotime($application['created'])) ?></td>
                            <td class="center"><?php print date("Y/m/d H:i:s A", strtotime($application['updated'])) ?></td>
                            <td class="center">
                            <?php 
                                switch ($application['status']) {
                                    case 2:
                                        print "Approved";
                                    break;  
                                    case 1:
                                        print "Verified";
                                    break;                                  
                                    default:
                                        print "Pending";
                                    break;
                                }          
                            ?>
                            </td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div>
<div id="applicationDetails" class="fluid">
    <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
        <colgroup>            
            <col class="con1" /> 
            <col class="con0" />
        </colgroup> 
        <tbody>
            <tr>    
                <td class="border strong">Program</td>
                <td class="border" id="program"></td>
            </tr>
            <tr>    
                <td class="strong">Service</td>
                <td id="service"></td>
            </tr> 
            <tr>    
                <td class="strong">Company</td>
                <td id="company"></td>
            </tr>
            <tr>    
                <td class="strong">Address</td>
                <td id="address"></td>
            </tr>
            <tr>    
                <td class="strong">Applicant</td>
                <td id="appicant"></td>
            </tr>
            <tr>    
                <td class="strong">Created</td>
                <td id="created"></td>
            </tr>
            <tr>    
                <td class="strong">Updated</td>
                <td id="updated"></td>
            </tr>
            <tr>    
                <td class="strong">Status</td>
                <td id="status"></td>
            </tr>
            <tr id="violations">    
                <td class="strong" colspan="2">Violations</td>           
            </tr>             
            <tr>    
                <td class="strong">Remarks</td>
                <td id="remarks"></td>
            </tr>
            <tr class="actions">    
                <td class="strong">Recommendation</td>
                <td id="recommendation"></td>
            </tr>
            <tr class="actions">    
                <td class="strong alignRight">On</td>
                <td id="actionOn"></td>
            </tr>
            <tr class="actions">    
                <td class="strong alignRight">By</td>
                <td id="actionBy"></td>
            </tr>              
        </tbody>
    </table>    
</div>
<script type="text/javascript">
jQuery("div.popup_buttons").css({"border":"1px solid #ddd","border-top":0});
jQuery("div#applicationDetails td.border").css({"border-top":"1px solid #ddd"});
var applicationDetails = jQuery("div#applicationDetails").hide();
jQuery("table.stdtable tr").dblclick(function(){
    var id = jQuery(this).find("td").first().find("input").val();
    jQuery.getJSON(BASE_PATH + "jsonapplication/" + id, function(json) { 
        var status;
        switch (json.status) {
            case 2:
                status = "Approved";
            break;  
            case 1:
                status = "Verified";
            break;                                  
            default:
                status = "Pending";
            break;
        }     
        applicationDetails.find("#service").empty().html(json.service);
        applicationDetails.find("#program").empty().html(json.program);
        applicationDetails.find("#company").empty().html(json.company);
        applicationDetails.find("#address").empty().html(json.address);
        applicationDetails.find("#appicant").empty().html(json.fname + " " + json.mname + " " + json.lname);     
        applicationDetails.find("#status").empty().html(status);
        applicationDetails.find("#created").empty().html(json.created);
        applicationDetails.find("#updated").empty().html(json.updated);
        applicationDetails.find("#remarks").empty().html(json.remarks);
        applicationDetails.find("#recommendation").empty().html(json.readyfor);
        applicationDetails.find("#actionOn").empty().html(json.actionOn);
        applicationDetails.find("#actionBy").empty().html(json.actionBy);        
        applicationDetails.find(".pdffile").remove();  
        applicationDetails.find(".violations").remove();         
        jQuery.each(json.pdffile, function(i,v){
            var img = jQuery("<img>", {"src":BASE_PATH + 'images/' + ((v.approved==0)? 'btn1' : 'btn2' )+ '.png'});
            var btn = jQuery("<span></span>", {class:"center"}).css({"border":"1px solid #ddd","display":"inline-block"}).append(img);
            var div = jQuery("<span></span>", {class:"center"}).css({"float":"right"}).append(btn);
            var row = jQuery("<tr></tr>", {class:"pdffile"});
            var td1 = jQuery("<td></td>", {class:"strong"}).html(v.file_for);
            var td2 = jQuery("<td></td>").html(v.pdf_file).append(div);
            row.append(td1).append(td2).insertBefore(applicationDetails.find("#violations"));            
        });
        if(json.violations.length) {            
            var violations = jQuery.parseJSON(json.violations);            
            jQuery.each(violations, function(i,violation_id){
                var tr = jQuery("<tr></tr>", {class:"violations"});
                var td = jQuery("<td></td>", {"colspan":2}).css({"background":"#fff"});     
                 
                jQuery.getJSON(BASE_PATH + "jsonviolations", function(json) { 
                    jQuery.each(json, function(i,v) {
                        if(v.id==violation_id) td.append(jQuery("<div></div>").html(v.name));
                    });
                });     

                tr.append(td);
                tr.insertAfter(applicationDetails.find(".violations").length? applicationDetails.find(".violations").last() : applicationDetails.find("#violations").show()); 
            });  
        } else
            applicationDetails.find("#violations").hide();

        if(json.readyfor.length) {
            applicationDetails.find(".actions").show();
        } else {
            applicationDetails.find(".actions").hide();
        }
        
        popup_box({class:randomstring(5), width:500, height:500, place:true, title:"Application", content:applicationDetails.show()}, {close:false});
    });    
});
</script>