<div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print $action ?>">applications</a></li>
            </ul>
            <div class="content">
                <div class="contenttitle">
                    <h2 class="form"><span>edit application</span></h2>
                </div>
                <form id="form2" class="stdform stdform2" method="post" enctype="multipart/form-data">
                    <p>
                        <label>Company</label>
                        <span class="field"><input type="text" name="company" class="longinput <?php print $filter ?>" value="<?php print $application['company'] ?>" /></span>
                    </p>
                    <p>
                        <label>Address <small>Address of the company.</small></label>
                        <span class="field"><textarea cols="80" rows="5" name="address" class="longinput <?php print $filter ?>"><?php print $application['address'] ?></textarea></span>
                    </p>
                    <p>
                        <label>Applicant <small>Representative of the company.</small></label>
                        <span class="field">
                            <input type="text" name="fname" class="longinput <?php print $filter ?>" value="<?php print $application['fname'] ?>" placeholder="First Name" />
                            <br /><br />
                            <input type="text" name="lname" class="longinput <?php print $filter ?>" value="<?php print $application['lname'] ?>" placeholder="Last Name" />
                            <br /><br />
                            <input type="text" name="mname" class="longinput <?php print $filter ?>" value="<?php print $application['mname'] ?>" placeholder="Middle Name" />
                        </span>
                    </p>
                    <p>
                        <label>Program</label>
                        <span class="field">
                            <select class="longinput <?php print $filter ?>" name="pid">
                            <?php foreach(getPrograms() as $key => $val): ?>
                                <option value="<?php print $key ?>" <?php if($key==$application['pid']) print "SELECTED" ?>><?php print $val ?></option>
                            <?php endforeach ?>
                            </select>
                        </span>
                    </p>
                    <p>
                        <label>Service</label>
                        <span class="field">
                            <select class="longinput <?php print $filter ?>" name="sid">
                            <?php 
                                $services = $CENRO->getServices($application['pid']);
                                if($services): foreach($services as $service): ?>
                                <option value="<?php print $service['id'] ?>" <?php if($service['id']==$application['sid']) print "SELECTED" ?>><?php print stripslashes($service['name']) ?></option>
                            <?php endforeach; endif ?>
                            </select>
                        </span>
                    </p>                    
                    <?php 
                        $ufRequirements = json_decode($application['requirements']);
                        $dbRequirements = $CENRO->getRequirements($application['sid']);                        
                        if($dbRequirements):
                            foreach ($dbRequirements as $r):
                                $id = $r['id'];
                                if(isset($ufRequirements->$id) AND $ufRequirements->$id->approved) continue;                             
                    ?>
                    <p class="requirements">
                        <label><?php print stripslashes($r['name']) ?></label>
                        <span class="field"><input type="file" name="<?php print 'requirement' . $id ?>" class="longinput" accept="application/pdf" /></span>
                    </p>  
                    <?php endforeach; endif ?>  
                    <p class="stdformbutton">
                        <button name="update" class="submit radius2 submitButton" onclick="return filterInput('<?php print $filter ?>')">Save</button>
                        <input type="reset" class="reset radius2 returnButton" value="Cancel" location="<?php print $action ?>" />
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){
    jQuery("input[name='firstname'], input[name='lastname']").filter_input({regex:"[a-z A-Z]"});
    jQuery("select[name='pid']").change(function(){
        var pid = jQuery(this).val();
        jQuery.getJSON(BASE_PATH + "jsonservices/" + pid, function(json){
            var services = jQuery("select[name='sid']").empty();
            jQuery.each(json, function(i,v){
                services.append(jQuery("<option value="+v.id+">"+v.name+"</option>"));
            });
            jQuery("select[name='sid']").trigger("change");
        });
    });
    jQuery("select[name='sid']").change(function(){
        var sid = jQuery(this).val();
        jQuery.getJSON(BASE_PATH + "jsonrequirements/" + sid, function(json){
            jQuery(".requirements").remove();
            jQuery.each(json, function(i,v){
                var p = jQuery("<p>", {class:"requirements"});
                var l = jQuery("<label></label>").html(v.name);
                var s = jQuery("<span></span>", {class:"field"});
                var f = jQuery("<input></input>", {class:"longinput","accept":"application/pdf","type":"file","name":"requirement"+v.id});  
                s.append(f);
                p.append(l).append(s).insertBefore(jQuery("p.stdformbutton"));
            });
        });        
    });
});   
</script>