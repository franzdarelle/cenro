<div class="headerinner" style="height:40px">      
    <div id="headerLogo"><?php print ACRONIM ?></div>
    <?php 
        $CENRO = new CENRO;
        $image = BASE_PATH . "images/avatar.png";
        if($CENRO->access->running()):
            if(($CENRO->access->getType()==1) OR ($CENRO->access->getType()==2)) {
                $profile = $CENRO->getProfileByUID($CENRO->access->getUser());
                if($profile['image']) $image = BASE_PATH . "upl/" . $profile['image'];
            }             
    ?>
    <div class="headright">        
        <div id="userPanel" class="headercolumn">
            <a href="#" class="userinfo radius2">
                <img src="<?php print $image ?>" class="radius2"/>
                <span><strong><?php print $CENRO->access->getName() ?></strong></span>
            </a>
            <div class="userdrop">
                <ul>
                    <li><a href="<?php print generateUrl('account') ?>">Account</a></li>
                    <li id="signOut" location="<?php print generateUrl('logout') ?>"><a href="#">Sign Out</a></li>
                </ul>
            </div>
        </div>
    </div>
    <?php endif ?>
</div>