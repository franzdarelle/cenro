<div class="loginbox radius3">
    <div class="loginboxinner radius3">
        <div class="loginheader">
            <h1 class="bebas">Sign In</h1>
            <div class="logo pointer" id="signinLogo"></div>
        </div>
        <div class="loginform">
            <form id="signinForm" method="post" ajaxlink="<?php print generateUrl('userauth') ?>" donelink="<?php print generateUrl('dashboard') ?>">
                <p>
                    <label for="username" class="bebas">Username</label>
                    <input name="username" id="username" class="radius2 <?php print $filter ?>" type="text" />
                </p>
                <p>
                    <label for="password" class="bebas">Password</label>
                    <input name="password" id="password" class="radius2 <?php print $filter ?>" type="password" />
                </p>
                <p>
                    <button name="<?php print $submit ?>" class="radius3 bebas" type="submit" onclick="return filterInput('<?php print $filter ?>')">Sign in</button>
                </p>
                <p><a href="#" class="whitelink small">Can't access your account?</a></p>
            </form>
        </div>
    </div>
</div>
<div id="forgotpass">
    <div class="stdform stdform2">
        <p>
            <label>Question</label>
            <span class="field">
                <select name="question" class="longinput dogz" required />
                    <?php foreach(getSecurityQuestions() as $k => $v): ?>
                    <option value="<?php print $k ?>"><?php print $v ?></option>
                    <?php endforeach ?>
                </select>
            </span>
        </p>
        <p>
            <label>Answer</label>
            <span class="field"><input name="myanswer" class="longinput dogz" type="text" required /></span>
        </p>
        <p>
            <label>Username</label>
            <span class="field"><input name="username" class="longinput dogz" type="text" required /></span>
        </p>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){

    var forgotpass = jQuery("#forgotpass").hide();

    jQuery(".whitelink").click(function(){
        forgotpass.find("span.field").css({"padding":10}).find("input").css({"width":"90%"});
        forgotpass.find("span.field").find("select").css({"width":"95%"});
        popup_box({title: "Forgot Password", content: forgotpass.show(), class:randomstring(5)}, { close:"Cancel", submit:true, name:"bart", id:"bart", class: "submitButton", value:"Retrieve", click: function() {
            if(filterInput("dogz")) {
                var q = forgotpass.find("select").val();
                var a = forgotpass.find("input[name='myanswer']").val();
                var u = forgotpass.find("input[name='username']").val();
                jQuery.ajax({
                    url: "<?php print generateUrl('forgotpass') ?>",
                    type: "POST",
                    data: {q:q,a:a,u:u}
                }).done(function(e){
                    var d = $.parseJSON(e);
                    popup_box({title:d.title, content:d.content}, {close:"Close"});
                });
            }
        }});
    });

    jQuery("#signinLogo").click(function(){
        jQuery(location).attr("href", "<?php print generateUrl('home') ?>");
    });

    if(<?php print (isset($failed) AND $failed)? "true" : "false" ?>) popup_box({content:"Access denied"}, {close:"Close"});
});
</script>