<div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print generateUrl('account') ?>">account</a></li>
            </ul>
            <div class="content">
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification <?php print $_SESSION[$CENRO->message]['type']? 'msgsuccess' : 'msgerror' ?>">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message]['text'] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle">
                    <h2 class="form"><span>account information</span></h2>
                </div>
                <form id="form2" class="stdform stdform2" method="post" action="#">
                    <p>
                        <label>Username</label>
                        <span class="field"><input readonly id="username" class="smallinput" value="<?php print $username ?>" type="text" /> <button id="username" type="button" class="stdbtn">Change</button></span>
                    </p>
                    <p>
                        <label>Password</label>
                        <span class="field"><input readonly id="password" class="smallinput" value="<?php print $password ?>" type="password" /> <button id="password" type="button" class="stdbtn">Change</button></span>
                    </p>
                    <p>
                        <label>Security Question / Answer <small>In case of forgot password</small></label>
                        <span class="field">
                            <input readonly class="smallinput" type="text" value="<?php print $secuques[$question] ?>" />
                            <button type="button" class="stdbtn security">Change</button>
                            <br /><br />
                            <input readonly class="smallinput" type="text" value="<?php print $myanswer ?>" /> 
                            <button type="button" class="stdbtn security">Change</button>
                        </span>
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<div id="changeUser">
    <div class="stdform stdform2">
        <p>
            <label>Username</label>
            <span class="field"><input name="username" class="longinput" required type="text" /></span>
        </p>
        <p>
            <label>Password</label>
            <span class="field"><input name="password" class="longinput" required type="password" /></span>
        </p>
    </div>
</div>
<div id="changePass">
    <div class="stdform stdform2">
        <p>
            <label>Old Password</label>
            <span class="field"><input name="opassword" class="longinput" type="password" required/></span>
        </p>
        <p>
            <label>New Password</label>
            <span class="field"><input name="npassword" class="longinput" type="password" required/></span>
        </p>
        <p>
            <label>Confirm Password</label>
            <span class="field"><input name="cpassword" class="longinput" type="password" required/></span>
        </p>
    </div>
</div>
<div id="reSecurity">
    <div class="stdform stdform2">
        <p>
            <label>Question</label>
            <span class="field">
                <select name="question" class="longinput" required />
                    <?php foreach($secuques as $k => $v): ?>
                    <option value="<?php print $k ?>" <?php if($k==$question) print "SELECTED" ?>><?php print $v ?></option>
                    <?php endforeach ?>
                </select>
            </span>
        </p>
        <p>
            <label>Answer</label>
            <span class="field"><input name="myanswer" class="longinput" type="text" value="<?php print $myanswer ?>" required /></span>
        </p>
    </div>
</div>
<script type="text/javascript">
var changeUser = jQuery("#changeUser").hide();
var changePass = jQuery("#changePass").hide();
var reSecurity = jQuery("#reSecurity").hide();
jQuery("button#username").click(function(){
    changeUser.find("span.field").css({"padding":10}).find("input").css({"width":"90%"});
    popup_box({
        start:"<form method='post'></form>", 
        title:"Change Username", 
        content: changeUser.show(), 
        width:500, 
        place:true, 
        class:randomstring(5)
    }, { submit:true, name:"changeUser", id:"changeUser", class: "submitButton", value:"Change", close:"Cancel" });
});
jQuery("button#password").click(function(){
    changePass.find("span.field").css({"padding":10}).find("input").css({"width":"90%"});
    popup_box({
        start:"<form method='post'></form>", 
        title:"Change Password", 
        content: changePass.show(), 
        width:500, 
        place:true, 
        class:randomstring(5)
    }, { submit:true, name:"changePass", id:"changePass", class: "submitButton", value:"Change", close:"Cancel" });
});
jQuery("button.security").click(function(){
    reSecurity.find("span.field").css({"padding":10}).find("input").css({"width":"90%"});
    reSecurity.find("span.field").find("select").css({"width":"95%"});
    popup_box({
        start:"<form method='post'></form>", 
        title:"Change Security Question / Answer", 
        content: reSecurity.show(), 
        width:500, 
        place:true, 
        class:randomstring(5)
    }, { submit:true, name:"reSecurity", id:"reSecurity", class: "submitButton", value:"Change", close:"Cancel" });
});
</script>