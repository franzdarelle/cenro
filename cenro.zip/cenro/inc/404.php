<div class="mainwrapperinner">   
    <div class="errorWrapper">
        <h1 class="pageErrorTitle">Error 404 - Page Not Found</h1>
        <span>You may have clicked an expired link or mistyped the address.</span>
    </div>
</div>