<?php 
    $arg = getArgument(2); 
    $tab = $arg? $arg : "complaint";
?>
<div class="mainwrapperinner">  
    <div class="mainleft">
        <div class="mainleftinner">
            <div class="leftmenu">
                <ul>
                    <li class="<?php print ($tab=='complaint')? 'home' : '' ?>"><a href="<?php print generateUrl('home/complaint') ?>" class="chat"><span>Complaint</span></a></li>
                    <li class="<?php print ($tab=='violations')? 'home' : '' ?>"><a href="<?php print generateUrl('home/violations') ?>" class="error"><span>Violations</span></a></li>
                    <li class="<?php print ($tab=='requirements')? 'home' : '' ?>"><a href="<?php print generateUrl('home/requirements') ?>" class="media"><span>Requirements</span></a></li> 
                    <li><a href="<?php print generateUrl('signin') ?>" class="editor"><span>Sign In</span></a></li>                   
                </ul>
            </div>
            <div id="togglemenuleft"><a></a></div>
        </div>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
        <?php if($tab=='complaint'): ?>
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print generateUrl('home/complaint') ?>">complaint</a></li>
            </ul>
            <div class="content">       
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>   
                <div class="contenttitle radiusbottom0">
                    <h2 class="complaints"><span>complaint</span></h2>
                </div>
                <form id="form2" class="stdform stdform2" method="post" enctype="multipart/form-data">
                    <p>
                        <label>Name</label>
                        <span class="field"><input type="text" class="longinput" name="name" /></span>
                    </p>
                    <p>
                        <label>Photo</label>
                        <span class="field"><input type="file" class="longinput" accept="image/*" name="photo" /></span>
                    </p>  
                    <p>
                        <label>Message</label>
                        <span class="field"><textarea cols="80" rows="5" name="message" class="longinput required"></textarea></span>
                    </p>
                    <p class="stdformbutton">
                        <button class="submit radius2 submitButton" id="send">Send</button>                         
                    </p>
                </form>
            </div>
        <?php endif ?>
        <?php if($tab=='violations'): ?>
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print generateUrl('home/violations') ?>">violations</a></li>
            </ul>
            <div class="content">          
                <div class="contenttitle radiusbottom0">
                    <h2 class="violations"><span>violations</span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <tbody>
                    <?php foreach ($CENRO->getViolations() as $v): ?>
                        <tr class="gradeX">   
                            <td><?php print stripslashes($v['name']) ?></td>
                            <td><?php print stripslashes($v['description']) ?></td>
                        </tr>                         
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        <?php endif ?>
        <?php if($tab=='requirements'): ?>
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print generateUrl('home/requirements') ?>">requirements</a></li>
            </ul>
            <div class="content">          
                <div class="contenttitle radiusbottom0">
                    <h2 class="items"><span>programs</span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable">
                    <tbody>
                    <?php foreach (getPrograms() as $key => $val): ?>
                        <tr class="gradeX">   
                            <td class="programs"><?php print $val ?></td>
                        </tr>
                        <?php 
                            $services = $CENRO->getServices($key);
                            if($services):
                                $serviceCount = "A";
                                foreach ($services as $s):
                        ?>
                            <tr class="gradeX">   
                                <td class="services"><?php print $serviceCount . '. ' . stripslashes($s['name']) ?></td>
                            </tr>
                            <?php 
                                $requirements = $CENRO->getRequirements($s['id']);
                                if($requirements):
                                    $requirementCount = 1;
                                    foreach ($requirements as $r):
                            ?>
                                <tr class="gradeX">   
                                    <td class="requirements"><?php print $requirementCount . '. ' . stripslashes($r['name']) ?></td>
                                </tr>
                            <?php $requirementCount++; endforeach; endif ?>
                        <?php $serviceCount++; endforeach; endif ?>
                    <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        <?php endif ?>
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>
<script type="text/javascript">
jQuery(document).ready(function(){ 
    jQuery(".programs").css({"font-weight":"bold","background":"#eee"});
    jQuery(".services").css({"font-weight":"bold","padding-left":50});
    jQuery(".requirements").css({"padding-left":100});
    jQuery("#send").click(function(){
        if(filterInput('required')) {
            jQuery(this).attr("name", "send").val("SEND");
            return true;
        }
        return false;
    });
});
</script>