<div class="mainleftinner">
    <div class="leftmenu">
        <ul>
        <?php if($_SESSION['WEBUSER']['type']==3): ?>            
            <li class="programs services addservice editservice requirements addrequirement"><a href="<?php print generateUrl('programs') ?>" class="tables"><span>Programs</span></a></li>            
            <li class="applications"><a href="<?php print generateUrl(implode("/", array("applications", "approved"))) ?>" class="media menudrop"><span>Applications</span></a>
                <ul>
                    <li><a href="<?php print generateUrl(implode("/", array("applications", "verified"))) ?>"><span>Verified</span></a></li>
                    <li><a href="<?php print generateUrl(implode("/", array("applications", "violated"))) ?>"><span>Violated</span></a></li>
                    <li><a href="<?php print generateUrl(implode("/", array("applications", "approved"))) ?>"><span>Approved</span></a></li> 
                </ul>
            </li>
            <li class="complaints"><a href="<?php print generateUrl('complaints') ?>" class="chat"><span>Complaints</span></a></li>
            <li class="violations"><a href="<?php print generateUrl('violations') ?>" class="error"><span>Violations</span></a></li>
            <li class="users addencoder editencoder addvalidator editvalidator"><a href="<?php print generateUrl(implode("/", array("users", "encoders"))) ?>" class="world menudrop"><span>Users</span></a>
                <ul>
                    <li><a href="<?php print generateUrl(implode("/", array("users", "encoders"))) ?>"><span>Encoders</span></a></li>
                    <li><a href="<?php print generateUrl(implode("/", array("users", "validators"))) ?>"><span>Validators</span></a></li>
                    <li><a href="<?php print generateUrl(implode("/", array("users", "applicants"))) ?>"><span>Applicants</span></a></li>
                </ul>
            </li>
        <?php endif ?>
        <?php if($_SESSION['WEBUSER']['type']==2): ?>
            <li class="applications"><a href="<?php print generateUrl(implode("/", array("applications", "pending"))) ?>" class="media menudrop"><span>Applications</span></a>
                <ul>
                    <li><a href="<?php print generateUrl(implode("/", array("applications", "pending"))) ?>"><span>Pending</span></a></li>
                    <li><a href="<?php print generateUrl(implode("/", array("applications", "verified"))) ?>"><span>Verified</span></a></li>                    
                </ul>
            </li>
            <li class="violations"><a href="<?php print generateUrl('violations') ?>" class="error"><span>Violations</span></a></li>
        <?php endif ?>
        <?php if($_SESSION['WEBUSER']['type']==1): ?>
            <li class="applications"><a href="<?php print generateUrl('applications') ?>" class="media"><span>Applications</span></a></li>
        <?php endif ?>
        <?php if($_SESSION['WEBUSER']['type']==0): ?>
            <li class="application"><a href="<?php print generateUrl('application') ?>" class="media"><span>Application</span></a></li>            
        <?php endif ?>
        </ul>
    </div>
    <div id="togglemenuleft"><a></a></div>
</div>