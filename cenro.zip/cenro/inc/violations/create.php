<div class="mainwrapperinner">  
    <div class="mainleft">
        <?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">
        <div class="maincontentinner">
            <ul class="maintabmenu">
                <li class="current"><a href="<?php print $action ?>">violations</a></li>
            </ul>
            <div class="content">
                <div class="contenttitle">
                    <h2 class="form"><span>add violation</span></h2>
                </div>
                <form id="form2" class="stdform stdform2" method="post">
                    <p>
                        <label>Name</label>
                        <span class="field"><input type="text" name="name" class="longinput <?php print $filter ?>" /></span>
                    </p>
                    <p>
                        <label>Description <small>Some information about this violation.</small></label>
                        <span class="field"><textarea cols="80" rows="5" name="description" class="longinput <?php print $filter ?>"></textarea></span>
                    </p>     
                    <p class="stdformbutton">
                        <button name="create" class="submit radius2 submitButton" onclick="return filterInput('<?php print $filter ?>')">Save</button>
                        <input type="reset" class="reset radius2 returnButton" value="Cancel" location="<?php print $action ?>" />
                    </p>
                </form>
            </div>
        </div>
        <div class="footer">
            <?php print getContents("footer") ?>
        </div>
    </div>
</div>