<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">  
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl('violations') ?>">violations</a></li>
            </ul>
            <div class="content">              
                <div class="contenttitle radiusbottom0">
                    <h2 class="violations"><span>violations</span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1">&nbsp;</th>
                            <th class="head1">Name</th>
                            <th class="head1">Description</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php      
                        $violations = $CENRO->getViolations();                  
                        if($violations): 
                            foreach($violations as $v):
                    ?>
                        <tr class="gradeX">
                            <td class="center">&nbsp;</td>
                            <td><?php print stripslashes($v['name']) ?></td>                            
                            <td><?php print stripslashes($v['description']) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div> 
<script type="text/javascript">jQuery("th:first-child, td:first-child").hide().next().css({"border-left":"1px solid #ccc"})</script>