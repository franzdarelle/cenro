<div class="mainwrapperinner">	
    <div class="mainleft">
      	<?php print getContents("sidebar") ?>
    </div>        
    <div class="maincontent noright">  
    	<div class="maincontentinner">
            <ul class="maintabmenu">
            	<li class="current"><a href="<?php print generateUrl('violations') ?>">violations</a></li>
            </ul>
            <div class="content">
                <?php if(isset($_SESSION[$CENRO->message])): ?>
                <div class="notification msgsuccess">
                    <a class="close"></a>
                    <p><?php print $_SESSION[$CENRO->message] ?></p>
                </div>
                <?php unset($_SESSION[$CENRO->message]); endif ?>
                <div class="contenttitle radiusbottom0">
                    <h2 class="violationsWithButton"><span><button class="stdbtn createButton" location="<?php print generateUrl('addviolation') ?>">+ Add</button><button class="stdbtn updateButton" location="<?php print generateUrl('editviolation') ?>" data-set="#dyntable .checkboxes">Edit</button><button class="stdbtn deleteButton" ajaxlink="<?php print generateUrl('deleteviolation') ?>" location="<?php print generateUrl('violations') ?>" data-set="#dyntable .checkboxes">Delete</button></span></h2>
                </div>
                <table cellpadding="0" cellspacing="0" border="0" class="stdtable" id="dyntable">
                    <colgroup>
                        <col class="con0" />
                        <col class="con0" />
                        <col class="con0" />
                    </colgroup>
                    <thead>
                        <tr>
                            <th class="head1"><input type="checkbox" class="checkall" /></th>
                            <th class="head1">Name</th>
                            <th class="head1">Description</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php      
                        $violations = $CENRO->getViolations();                  
                        if($violations): 
                            foreach($violations as $v):
                    ?>
                        <tr class="gradeX">
                            <td class="center"><input type="checkbox" value="<?php print $v['id'] ?>" class="checkboxes" /></td>
                            <td><?php print stripslashes($v['name']) ?></td>                            
                            <td><?php print stripslashes($v['description']) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>        
        </div>
        <div class="footer">
        	<?php print getContents("footer") ?>
        </div>
    </div>
</div> 