<?php
$CONTENT = array();
$REQUEST = isset($_GET['q'])? trim(@$_GET['q']) : "home";

$ROUTER = new ROUTER;
$PARAMS = explode("/", $REQUEST);
$METHOD = ((int)method_exists($ROUTER, $PARAMS[0]) AND is_callable(array($ROUTER, $PARAMS[0])))? $PARAMS[0] : "error";
$CONTENT = $ROUTER->$METHOD($PARAMS);
 
class ROUTER {

	var $CENRO, $accept = array('png','jpg','jpeg','gif','bmp');	

	function __construct() { $this->CENRO = new CENRO; }

	public function logout() {
		session_destroy();
        clearstatcache();
		header("Location: " . generateUrl("signin"));
	    exit;
	}

	public function error() {
		return array(
			'title' => "404 Page",
			'header' => true,
			'script' => array(
				'plugins/jquery-1.7.min.js',
				'plugins/jquery-ui-1.8.16.custom.min.js',
				'custom/general.js'
			),
			'content' => getContents("404")
		);
	}

	public function signin() {
		$params = array(
			'filter' => randomString(),
			'submit' => 'userDataSend'
		);
		if(isset($_POST[$params['submit']])) {
			$data = array_map("addslashes", $_POST);
			if($this->CENRO->signin($data['username'], $data['password'])) {
				switch ($this->CENRO->access->getType()) {
					case 3:
						#Admin / Department Head
						$location = generateUrl("applications/verified");
					break;
					case 2:
						#Validators
						$location = generateUrl("applications/pending");
					break;
					case 1:
						#Encoders
						$location = generateUrl("applications");
					break;					
					default:
						#Applicants
						$location = generateUrl("application");
					break;
				}
				header("Location: " . $location);
	    		exit;							
			} else
				$params['failed'] = true;
		}
		return array(
			'title' => "Sign In",
			'header' => false,
			'script' => array('plugins/jquery-1.7.min.js'),
			'content' => getContents("signin", $params)
		);
	}

	public function forgotpass() {
		$q = $_POST['q'];
		$a = $_POST['a'];
		$u = $_POST['u'];
		$file = $this->CENRO->getForgotPassword($u, $q, $a);
		$pass = $file? array("title"=>"Password","content"=>$this->CENRO->getContent($file . '.txt')) : array("title"=>"Message","content"=>"No password found");
		exit(json_encode($pass));
	}

	public function account() {
		if($this->CENRO->access->running()) {
			if(isset($_POST['changeUser'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->changeUsername($data['username'], $data['password']);
				switch ($save) {
					case 0:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 0,
							"text" => "Invalid password."
						);
					break;
					case 1:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 0,
							"text" => "Username must be atleast 6 (six) characters."
						);
					break;
					case 2:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 1,
							"text" => "Username successfully changed."
						);
					break;
				}
			}
			if(isset($_POST['changePass'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->changePassword($data['opassword'], $data['npassword'], $data['cpassword']);
				switch ($save) {
					case 0:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 0,
							"text" => "Invalid password."
						);
					break;
					case 1:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 0,
							"text" => "Please confirm your password."
						);
					break;
					case 2:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 0,
							"text" => "Password must be atleast 6 (six) characters."
						);
					break;
					case 3:
						$_SESSION[$this->CENRO->message] = array(
							"type" => 1,
							"text" => "Password successfully changed."
						);
					break;
				}
			}
			if(isset($_POST['reSecurity'])) {
				$save = $this->CENRO->changeSecurity($_POST['question'], addslashes($_POST['myanswer']), $this->CENRO->access->getUser());
				if($save) {
					$_SESSION[$this->CENRO->message] = array(
						"type" => 1,
						"text" => "Security question / answer successfully changed."
					);
				}
			}
			$data = $this->CENRO->getUser($this->CENRO->access->getUser());
			$user['username'] = $this->CENRO->access->getName();
			$user['password'] = $this->CENRO->getContent($this->CENRO->getShadow($this->CENRO->access->getUser()).'.txt');
			$user['question'] = $data['sque'];
			$user['myanswer'] = $data['sans'];
			$user['secuques'] = getSecurityQuestions();
			return array(
				'title' => "Account",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("account", array_merge(array('CENRO'=>$this->CENRO), $user))
			);
		} else
			return $this->logout();
	}

	public function users($args) {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType()) {
			$path = strtolower($args[1]);
			switch ($path) {
				case 'validators':
					$type = 2;
				break;
				case 'encoders':
					$type = 1;
				break;
				default:
					$type = 0;
				break;
			}	 
			return array(
				'title' => "Users",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents(implode("/", array("users", $path, "users")), ['CENRO'=>$this->CENRO, 'type'=>$type, 'link'=>$path])
			);
		} else
			$this->logout();
	}

	public function addencoder() {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType()) {
			$link = generateUrl("users/encoders");
			if(isset($_POST['create'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->addUserAccount($data['username'], $data['password'], 1);
				if($save) {
					$image = '';
					if(isset($_FILES['image']) AND ($_FILES['image']['size'] > 0)) {
						$type = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
						if(in_array($type, $this->accept)) {				
							$name = strtolower(randomString(10)) . '.' . $type;
							$move = move_uploaded_file($_FILES['image']['tmp_name'], BASE_ROOT . '/upl/' . $name);
							if($move) $image = $name;
						}
					}
					if($this->CENRO->addProfile($save, 0, $image, ucwords(strtolower($data['lname'])), ucwords(strtolower($data['fname'])), ucwords(strtolower($data['mname'])), $data['email'], $data['contact'], $data['address'], $data['position'])) {
						$_SESSION[$this->CENRO->message] = 'Encoder successfully created.';
					}					
					header("Location: " . $link);
	    			exit;
				}				
			}
			return array(
				'title' => "Add Encoder",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("users/encoders/create", array('filter' => randomString(), 'action'=> $link)) 
			);
		} else
			return $this->logout();
	}

	public function editencoder($args) {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType() AND $args[1]) {
			$id = $args[1];
			$link = generateUrl("users/encoders");

			if(isset($_POST['update'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->setUserAccount($data['username'], $data['password'], $id);
				if($save) {
					$image = $data['image'];
					if(isset($_FILES['image']) AND ($_FILES['image']['size'] > 0)) {
						$type = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
						if(in_array($type, $this->accept)) {				
							$name = strtolower(randomString(10)) . '.' . $type;
							$move = move_uploaded_file($_FILES['image']['tmp_name'], BASE_ROOT . '/upl/' . $name);
							if($move) $image = $name;
						}
					}
					if($this->CENRO->setProfile(0, $image, ucwords(strtolower($data['lname'])), ucwords(strtolower($data['fname'])), ucwords(strtolower($data['mname'])), $data['email'], $data['contact'], $data['address'], $data['position'], $data['profile_id'])) {
						$_SESSION[$this->CENRO->message] = 'Encoder successfully updated.';
					}					
					header("Location: " . $link);
	    			exit; 
				}				
			} 

			$user = $this->CENRO->getUser($id);
			$profile = $this->CENRO->getProfileByUID($id);		 
			$email = stripslashes($profile['email']);
			$contact = stripslashes($profile['contact']);
			$address = stripslashes($profile['address']);
			$position = stripslashes($profile['position']);
			$username = $user['user'];
			$password = $this->CENRO->getContent($user['file'].".txt");

			return array(
				'title' => "Edit Encoder",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("users/encoders/update", array(
					'filter' => randomString(), 
					'action' => $link, 			 
					'image' => $profile['image'],
					'lname' => $profile['lname'],
					'fname' => $profile['fname'],
					'mname' => $profile['mname'],
					'email' => $email,
					'contact' => $contact,
					'address' => $address,
					'position' => $position,
					'username' => $username, 
					'password' => $password,
					'profile_id' => $profile['id']
				))
			);
		}
	}

	public function addvalidator() {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$link = generateUrl("users/validators");
			if(isset($_POST['create'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->addUserAccount($data['username'], $data['password'], 2);
				if($save) {
					$image = '';
					if(isset($_FILES['image']) AND ($_FILES['image']['size'] > 0)) {
						$type = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
						if(in_array($type, $this->accept)) {				
							$name = strtolower(randomString(10)) . '.' . $type;
							$move = move_uploaded_file($_FILES['image']['tmp_name'], BASE_ROOT . '/upl/' . $name);
							if($move) $image = $name;
						}
					}
					if($this->CENRO->addProfile($save, $data['pid'], $image, ucwords(strtolower($data['lname'])), ucwords(strtolower($data['fname'])), ucwords(strtolower($data['mname'])), $data['email'], $data['contact'], $data['address'], $data['position'])) {
						$_SESSION[$this->CENRO->message] = 'Validator successfully created.';
					}					
					header("Location: " . $link);
	    			exit;
				}				
			}
			return array(
				'title' => "Add Validator",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("users/validators/create", array('filter' => randomString(), 'action'=> $link)) 
			);
		} else
			return $this->logout();
	}

	public function editvalidator($args) {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType() AND $args[1]) {
			$id = $args[1];
			$link = generateUrl("users/validators");

			if(isset($_POST['update'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->setUserAccount($data['username'], $data['password'], $id);
				if($save) {
					$image = $data['image'];
					if(isset($_FILES['image']) AND ($_FILES['image']['size'] > 0)) {
						$type = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
						if(in_array($type, $this->accept)) {				
							$name = strtolower(randomString(10)) . '.' . $type;
							$move = move_uploaded_file($_FILES['image']['tmp_name'], BASE_ROOT . '/upl/' . $name);
							if($move) $image = $name;
						}
					}
					if($this->CENRO->setProfile($data['pid'], $image, ucwords(strtolower($data['lname'])), ucwords(strtolower($data['fname'])), ucwords(strtolower($data['mname'])), $data['email'], $data['contact'], $data['address'], $data['position'], $data['profile_id'])) {
						$_SESSION[$this->CENRO->message] = 'Validator successfully updated.';
					}					
					header("Location: " . $link);
	    			exit;
				}
			}

			$user = $this->CENRO->getUser($id);
			$profile = $this->CENRO->getProfileByUID($id);		 
			$email = stripslashes($profile['email']);
			$contact = stripslashes($profile['contact']);
			$address = stripslashes($profile['address']);
			$position = stripslashes($profile['position']);
			$username = $user['user'];
			$password = $this->CENRO->getContent($user['file'].".txt");

			return array(
				'title' => "Edit Encoder",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("users/validators/update", array(
					'filter' => randomString(), 
					'action' => $link, 
					'image' => $profile['image'],
					'lname' => $profile['lname'],
					'fname' => $profile['fname'],
					'mname' => $profile['mname'],
					'email' => $email,
					'contact' => $contact,
					'address' => $address,
					'position' => $position,
					'username' => $username, 
					'password' => $password,
					'program_id' => $profile['pid'],
					'profile_id' => $profile['id']
				))
			);
		}
	}

	public function deleteuser() {
		if(isset($_POST['items']) AND $this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$deleted = 0;
			foreach ($_POST['items'] as $id) {
				$user = $this->CENRO->getUser($id);
				$file = $user['file'] . ".txt";
				if($this->CENRO->deleteUserAccount($id)) {					
					//$this->CENRO->remShadow($file);
					$deleted++;
				}
			}
			if($deleted) $_SESSION[$this->CENRO->message] = (($deleted>1)? $deleted . ' users' : 'User') . ' successfully deleted.';
			exit($deleted);
		}
	}
	
	public function programs() {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType()) {			 
			return array(
				'title' => "Programs",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("services/programs")
			);
		} else
			$this->logout();
	}

	public function services($args) {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {			 
			return array(
				'title' => "Services",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("services/services", ['CENRO'=>$this->CENRO, 'pid' => $args[1]])
			);
		} else
			$this->logout();
	}

	public function addservice($args) {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$programs = getPrograms();
			$pid = $args[1];
			$link = generateUrl(implode("/", array("services", $pid)));
			if(isset($_POST['create'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->addService($pid, $data['name'], $data['description']);
				if($save) {
					$_SESSION[$this->CENRO->message] = 'Service successfully created.';
					header("Location: " . $link);
	    			exit;
				}				
			}			
			return array(
				'title' => "Add Service",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("services/create", array(
					'filter' => randomString(), 
					'action' => $link, 
					'program' => $programs[$pid]
				)) 
			);
		} else
			return $this->logout();
	}

	public function editservice($args) {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType() AND $args[1] AND $args[2]) {

			$pid = $args[1];
			$id = $args[2];
			$link = generateUrl(implode("/", array("services", $pid)));			

			if(isset($_POST['update'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->setService($data['name'], $data['description'], $id);
				if($save) {
					$_SESSION[$this->CENRO->message] = 'Service successfully updated.';
					header("Location: " . $link);
	    			exit;
				}				
			}	

			$programs = getPrograms();
			$service = $this->CENRO->getService($id);
			$name = $service['name'];
			$description = $service['description'];

			return array(
				'title' => "Edit Service",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("services/update", array(
					'filter' => randomString(), 
					'action' => $link, 
					'name' => $name, 
					'description' => $description,
					'program' => $programs[$pid]
				))
			);
		}
	}

	public function deleteservice() {
		if(isset($_POST['items']) AND $this->CENRO->access->running() AND $this->CENRO->access->getType()) {
			$deleted = 0;
			foreach ($_POST['items'] as $id) {				
				if($this->CENRO->deleteService($id)) $deleted++;
			}
			if($deleted) $_SESSION[$this->CENRO->message] = (($deleted>1)? $deleted . ' services' : 'Service') . ' successfully deleted.';
			exit($deleted);
		}
	}

	public function requirements($args) {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {			 
			return array(
				'title' => "Requirements",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("services/requirements", ['CENRO' => $this->CENRO, 'sid' => $args[1]])
			);
		} else
			$this->logout();
	}

	public function addrequirement($args) {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			 
			$sid = $args[1];
			$link = generateUrl(implode("/", array("requirements", $sid)));


			if(isset($_POST['create'])) {
				$save = $this->CENRO->addRequirement($sid, addslashes($_POST['name']));
				if($save) {
					$_SESSION[$this->CENRO->message] = 'Requirement successfully created.';
					header("Location: " . $link);
	    			exit;
				}				
			}

			$service = $this->CENRO->getService($sid);	
			$programs = getPrograms();	
			return array(
				'title' => "Add Requirement",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("services/addrequirement", array(
					'filter' => randomString(), 
					'action' => $link, 
					'service' => stripslashes($service['name']),
					'pid' => $service['pid'],
					'program' => $programs[$service['pid']]
				)) 
			);
		} else
			return $this->logout();
	}

	public function editrequirement($args) {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType() AND $args[1] AND $args[2]) {

			$sid = $args[1];
			$id = $args[2];
			$link = generateUrl(implode("/", array("requirements", $sid)));		
			
			if(isset($_POST['update'])) {
				$save = $this->CENRO->setRequirement(addslashes($_POST['name']), $id);
				if($save) {
					$_SESSION[$this->CENRO->message] = 'Requirement successfully updated.';
					header("Location: " . $link);
	    			exit;
				}				
			}	
					
			$service = $this->CENRO->getService($sid);
			$requirement = $this->CENRO->getRequirement($id);
			$programs = getPrograms();

			return array(
				'title' => "Edit Requirement",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("services/editrequirement", array(
					'filter' => randomString(), 
					'action' => $link, 
					'name' => stripslashes($requirement['name']),
					'service' => stripslashes($service['name']),
					'pid' => $service['pid'],
					'program' => $programs[$service['pid']]
				))
			);
		}
	}

	public function deleterequirement() {
		if(isset($_POST['items']) AND $this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$deleted = 0;
			foreach ($_POST['items'] as $id) {				
				if($this->CENRO->deleteRequirement($id)) $deleted++;
			}
			if($deleted) $_SESSION[$this->CENRO->message] = (($deleted>1)? $deleted . ' requirements' : 'Requirement') . ' successfully deleted.';
			exit($deleted);
		}
	}

	public function violations($args) {
		if($this->CENRO->access->running() AND (($this->CENRO->access->getType()==2) OR ($this->CENRO->access->getType()==3))) {			 
			return array(
				'title' => "Violations",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("violations/violations" . $this->CENRO->access->getType(), ['CENRO'=>$this->CENRO])
			);
		} else
			$this->logout();
	}

	public function complaints() {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {			 
			return array(
				'title' => "Complaints",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("complaints/complaints", ['CENRO'=>$this->CENRO])
			);
		} else
			$this->logout();
	}

	public function deletecomplaint() {
		if(isset($_POST['items']) AND $this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$deleted = 0;
			foreach ($_POST['items'] as $id) {				
				if($this->CENRO->deleteComplaint($id)) $deleted++;
			}
			if($deleted) $_SESSION[$this->CENRO->message] = (($deleted>1)? $deleted . ' complaints' : 'Complaint') . ' successfully deleted.';
			exit($deleted);
		}
	}

	public function addviolation($args) {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$link = generateUrl("violations");
			if(isset($_POST['create'])) {
				$data = array_map("addslashes", $_POST);			 
				$save = $this->CENRO->addViolation($data['name'], $data['description']);
				if($save) {
					$_SESSION[$this->CENRO->message] = 'Violation successfully created.';
					header("Location: " . $link);
	    			exit;
				}				
			}		
			return array(
				'title' => "Add Violation",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("violations/create", array(
					'filter' => randomString(), 
					'action' => $link
				)) 
			);
		} else
			return $this->logout();
	}

	public function editviolation($args) {
		if($this->CENRO->access->running() AND $this->CENRO->access->getType() AND $args[1]) {

			$id = $args[1];
			$link = generateUrl("violations");			

			if(isset($_POST['update'])) {
				$data = array_map("addslashes", $_POST);
				$save = $this->CENRO->setViolation($data['name'], $data['description'], $id);
				if($save) {
					$_SESSION[$this->CENRO->message] = 'Violation successfully updated.';
					header("Location: " . $link);
	    			exit;
				}				
			}

			$violation = $this->CENRO->getViolation($id);
			$name = $violation['name'];
			$description = $violation['description'];

			return array(
				'title' => "Edit Violation",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("violations/update", array(
					'filter' => randomString(), 
					'action' => $link, 
					'name' => $name, 
					'description' => $description
				))
			);
		}
	}

	public function deleteviolation() {
		if(isset($_POST['items']) AND $this->CENRO->access->running() AND ($this->CENRO->access->getType()==3)) {
			$deleted = 0;
			foreach ($_POST['items'] as $id) {				
				if($this->CENRO->deleteViolation($id)) $deleted++;
			}
			if($deleted) $_SESSION[$this->CENRO->message] = (($deleted>1)? $deleted . ' violations' : 'Violation') . ' successfully deleted.';
			exit($deleted);
		}
	}

	public function application() {
		if($this->CENRO->access->running() AND !$this->CENRO->access->getType()) {
			$user = $this->CENRO->getUser($this->CENRO->access->getUser());
			$apps = $this->CENRO->getApplication($user['apps']);			 
			return array(
				'title' => "Application",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("applications/application", ['CENRO' => $this->CENRO, 'apps' => $apps])
			);
		} else
			$this->logout();
	}

	public function applications($args) { 
		if($this->CENRO->access->running()) {			 
			return array(
				'title' => (isset($args[1])? ucfirst($args[1]) : "Applications"),
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("applications/applications" . $this->CENRO->access->getType(), ['CENRO'=>$this->CENRO])
			);
		} else
			$this->logout();
	}

	public function addapplication() {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==1)) {

			$link = generateUrl("applications");

			if(isset($_POST['create'])) {
				$data = array_map("addslashes", $_POST);
				$dbRequirements = $this->CENRO->getRequirements($data['sid']);
				$ufRequirements = array(); 
				foreach ($dbRequirements as $r) {

					$id = $r['id'];
					$rn = 'requirement'.$id;

					if(isset($_FILES[$rn]) AND ($_FILES[$rn]['size'] > 0)) {
						$file = $_FILES[$rn];
						$type = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
						if($type=="pdf") {
							$name = strtolower(randomString(10)) . '.' . $type;
							$move = move_uploaded_file($file['tmp_name'], BASE_ROOT . '/upl/' . $name);
							if($move) {
								$ufRequirements[$id] = array(
									'pdf_file' => $name,
									'approved' => 0
								);
							}
						} else
							$_SESSION[$this->CENRO->warning] = 'Invalid file type for ' . stripslashes($r['name']);
					}
				} 

				$save = $this->CENRO->addApplication($data['pid'], $data['sid'], $this->CENRO->access->getUser(), ucwords(strtolower($data['fname'])), ucwords(strtolower($data['lname'])), ucwords(strtolower($data['mname'])), $data['company'], $data['address'], json_encode($ufRequirements), date("Y-m-d H:i:s"));
				if($save) {
					$this->CENRO->addUserAccount(strtolower(implode("", explode(" ", $data['fname']))), strtolower(implode("", explode(" ", $data['lname']))), 0, $save);
					$_SESSION[$this->CENRO->message] = 'Application successfully created.';
					header("Location: " . $link);
	    			exit;
				}
			}

			return array(
				'title' => "Add Application",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery.dataTables.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js',
					'custom/tables.js'
				),
				'content' => getContents("applications/create", array(
					'CENRO' =>$this->CENRO,
					'filter' => randomString(), 
					'action' => $link
				)) 
			);
		} else
			return $this->logout();
	}

	public function editapplication($args) {
		if($this->CENRO->access->running() AND ($this->CENRO->access->getType()==1) AND $args[1]) {
			
			$appid = $args[1];
			$link = generateUrl("applications");
			$apps = array_map("stripslashes", $this->CENRO->getApplication($appid));

			# Approved / Verified
			if($apps['status']) {
				header("Location: " . $link);
	    		exit;
			}

		 	if(isset($_POST['update'])) {
				$data = array_map("addslashes", $_POST);
				$dbRequirements = $this->CENRO->getRequirements($data['sid']);
				$drRequirements = json_decode($apps['requirements']);
				$ufRequirements = array(); 
				foreach ($dbRequirements as $r) {

					$id = $r['id'];
					$rn = 'requirement'.$id;

					$ufRequirements[$id] = array(
						'pdf_file' => $drRequirements->$id->pdf_file,
						'approved' => $drRequirements->$id->approved
					);

					if(isset($_FILES[$rn]) AND ($_FILES[$rn]['size'] > 0)) {
						$file = $_FILES[$rn];
						$type = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
						if($type=="pdf") {
							$name = strtolower(randomString(10)) . '.' . $type;
							$move = move_uploaded_file($file['tmp_name'], BASE_ROOT . '/upl/' . $name);
							if($move) {
								$ufRequirements[$id] = array(
									'pdf_file' => $name,
									'approved' => 0
								);
							}
						} else
							$_SESSION[$this->CENRO->warning] = 'Invalid file type for ' . stripslashes($r['name']);
					}
				} 	 

				$save = $this->CENRO->updateApplication(ucwords(strtolower($data['fname'])), ucwords(strtolower($data['lname'])), ucwords(strtolower($data['mname'])), $data['company'], $data['address'], json_encode($ufRequirements), $data['pid'], $data['sid'], $appid);
				$user = $this->CENRO->getUserByApps($appid);
				if($save) {
					$newUser = strtolower(implode("", explode(" ", $data['fname'])));
					$newPass = strtolower(implode("", explode(" ", $data['lname'])));
					if(($user['user']==$newUser) AND ($user['pass']==$this->CENRO->getContent($this->CENRO->getShadow($user['id']).'.txt'))) {}
					else {
						$this->CENRO->setUserAccount($newUser, $newPass, $user['id']);
					}
					$_SESSION[$this->CENRO->message] = 'Application successfully updated.';
					header("Location: " . $link);
	    			exit;
				}				
			}

			return array(
				'title' => "Edit Application",
				'header' => true,
				'script' => array(
					'plugins/jquery-1.7.min.js',
					'plugins/jquery-ui-1.8.16.custom.min.js',
					'custom/general.js'
				),
				'content' => getContents("applications/update", array(
					'CENRO' =>$this->CENRO,
					'filter' => randomString(), 
					'action' => $link, 
					'application' => $apps
				))
			);
		} else
			return $this->logout();
	}

	public function deleteapplication() {
		if(isset($_POST['items']) AND $this->CENRO->access->running() AND (($this->CENRO->access->getType()==2) OR ($this->CENRO->access->getType()==3))) {
			$deleted = 0;
			foreach ($_POST['items'] as $id) {				
				if($this->CENRO->deleteApplication($id) AND $this->CENRO->deleteApplicant($id)) $deleted++;
			}
			if($deleted) $_SESSION[$this->CENRO->message] = (($deleted>1)? $deleted . ' applications' : 'Application') . ' successfully deleted.';
			exit($deleted);
		}
	}

	public function verifyapplication() {
		if(isset($_POST['id'])) {
			if($this->CENRO->verifyApplication($_POST['id'])) {
				$_SESSION[$this->CENRO->message] = 'Application successfully verified.';
				return true;
			}
		}
	}

	public function disapproveapplication() {
		if(isset($_POST['id'])) {
			if($this->CENRO->disapproveApplication($_POST['id'])) return true;
		}
	}

	public function approveapplication() {
		if(isset($_POST['id'])) {
			if($this->CENRO->approveApplication($_POST['id'])) {
				$_SESSION[$this->CENRO->message] = 'Application successfully approved.';
				return true;
			}
		}
	}	

	public function remarksapplication() {
		if(isset($_POST['id']) AND isset($_POST['remarks'])) { 
			return $this->CENRO->remarksApplication($_POST['remarks'], $_POST['id']);
		}
	}

	public function recommendationapplication() {
		if(isset($_POST['id']) AND isset($_POST['recommendation'])) {
			return $this->CENRO->recommendationApplication($_POST['recommendation'], $_POST['id']);
		}
	}

	public function actionOnapplication() {
		if(isset($_POST['id']) AND isset($_POST['actionOn'])) { 
			return $this->CENRO->actionOnApplication($_POST['actionOn'], $_POST['id']);
		}
	}

	public function actionByapplication() {
		if(isset($_POST['id']) AND isset($_POST['actionBy'])) {
			return $this->CENRO->actionByApplication($_POST['actionBy'], $_POST['id']);
		}
	}

	public function violationapplication() {
		if(isset($_POST['id'])) {
			$vids = isset($_POST['vids'])? json_encode($_POST['vids']) : '';			 
			return $this->CENRO->setApplicationViolations($vids, $_POST['id']);
		}
	}

	public function historyapplication() {
		if(isset($_POST['id']) AND isset($_POST['vid'])) {
			$id = $_POST['id'];
			$vid = $_POST['vid'];
			$history = $this->CENRO->getApplicationHistory($id);
			$history = $history? json_decode($history) : array();
			array_push($history, $vid);
			$this->CENRO->setApplicationHistory(json_encode($history), $id);

			$violation = $this->CENRO->getViolation($vid);
			exit(stripslashes($violation['name']));
		}
	}

	public function verifypdffile() {
		if(isset($_POST['aid']) AND isset($_POST['rid']) AND isset($_POST['val'])) {
			$application = $this->CENRO->getApplication($_POST['aid']);
			$dbRequirements = $this->CENRO->getRequirements($application['sid']);
			$drRequirements = json_decode($application['requirements']); 
			$ufRequirements = array();
			foreach ($dbRequirements as $r) {
				$id = $r['id'];
				if (isset($drRequirements->$id)) {
					if ($id==$_POST['rid']) {
						$ufRequirements[$id] = array(
							'pdf_file' => $drRequirements->$id->pdf_file,
							'approved' => $_POST['val']
						);
					}  else {
						$ufRequirements[$id] = array(
							'pdf_file' => $drRequirements->$id->pdf_file,
							'approved' => $drRequirements->$id->approved
						);
					}
				} else {
					$ufRequirements[$id] = array(
						'pdf_file' => "",
						'approved' => 0
					);	
				}				
			}
			$approved = 0;
			$pdffiles = 0;
			foreach ($ufRequirements as $pdf) {
				if($pdf['approved']) $approved++;
				$pdffiles++;
			}
			$verified = $this->CENRO->setApplicationRequirements(json_encode($ufRequirements), $_POST['aid'])? true : false; 
			exit(json_encode(array(
				'verified' => $verified,
				'approved' => $approved,
				'pdffiles' => $pdffiles
			)));
		}
	}

	public function jsonapplication($args) {	
		$programs = getPrograms(); 
		$recommendations = getRecommendations();
		$application = array_map("stripslashes", $this->CENRO->getApplication($args[1]));
		$dbRequirements = $this->CENRO->getRequirements($application['sid']);
		$drRequirements = json_decode($application['requirements']); 
		$ufRequirements = array();
		foreach ($dbRequirements as $r) {
			$id = $r['id'];
			if(isset($drRequirements->$id) AND isset($drRequirements->$id->approved) AND $drRequirements->$id->pdf_file) {
				$ufRequirements[$id] = array(
					'file_for' => stripslashes($r['name']),
					'pdf_file' => getUPLFileLink($drRequirements->$id->pdf_file),
					'approved' => $drRequirements->$id->approved
				);
			} else {
				$ufRequirements[$id] = array(
					'file_for' => stripslashes($r['name']),
					'pdf_file' => "",
					'approved' => 0
				);
			}			
		}
		$application['program'] = $programs[$application['pid']];
		$application['pdffile'] = $ufRequirements;
		$application['created'] = date("Y/m/d H:i:s A", strtotime($application['created']));
        $application['updated'] = date("Y/m/d H:i:s A", strtotime($application['updated']));
        $application['readyfor'] = $application['recommendation']? $recommendations[$application['recommendation']] : false;       
		exit(json_encode($application));
	}

	public function jsonservices($args) {
		exit(json_encode($this->CENRO->getServices($args[1])));
	}

	public function jsonrequirements($args) {
		exit(json_encode($this->CENRO->getRequirements($args[1])));
	}

	public function jsonviolations() {
		exit(json_encode($this->CENRO->getViolations()));
	}

	public function jsoncountverifiedpdf() {
		if(isset($_POST['id'])) {
			$application = $this->CENRO->getApplication($_POST['id']);
			$dbRequirements = $this->CENRO->getRequirements($application['sid']);
			$drRequirements = json_decode($application['requirements']);
			$approved = 0;
			$pdffiles = 0;
			foreach ($dbRequirements as $r) {
				$id = $r['id'];
				if (isset($drRequirements->$id)) {
					if($drRequirements->$id->approved) $approved++;
				}	
				$pdffiles++;		
			}
			exit(json_encode(array(	 
				'approved' => $approved,
				'pdffiles' => $pdffiles
			)));
		}
	}

	public function jsoncomplaint($args) {
		$complaint = array_map("stripslashes", $this->CENRO->getComplaint($args[1]));
		$complaint['name'] = $complaint['name']? $complaint['name'] : 'Anonymous';
		$complaint['date'] = date("Y/m/d H:i:s A", strtotime($complaint['date']));
		exit(json_encode($complaint));
	}

	public function androidsignin() {
		if(isset($_REQUEST['auth']) AND ($_REQUEST['auth']=="android_app")) {
			$data = array_map("addslashes", $_REQUEST);
			if($this->CENRO->signin($data['user'], $data['pass'])) {
				if(!$this->CENRO->access->getType()) {
					$user = $this->CENRO->getUser($this->CENRO->access->getUser());
					exit(json_encode(array(
						"user" => $this->CENRO->access->getUser(),						 
						"apps" => $user['apps'],
						"auth" => 1						
					)));
				}
			}
		}
		exit(json_encode(array("auth" => 0)));		
	}

	public function reports($args) {
		include_once LIBRARIES . "DOMPDF.php";
		$dompdf = new DOMPDF(); 
		$report = "report_" . strtolower($args[1]);

		$content = getContents("reports/" . $report, array('CENRO' => $this->CENRO));
		if(get_magic_quotes_gpc()) $content = stripslashes($content);

		$dompdf->load_html($content);
		$dompdf->set_paper("legal", "landscape");
		$dompdf->render();
		$dompdf->stream($report . ".pdf", array("Attachment" => false));
		exit;
	}

	public function home() {
		if(isset($_POST['send']) AND ($_POST['send']=="SEND")) {
			$photo = '';
			if(isset($_FILES['photo']) AND ($_FILES['photo']['size'] > 0)) {
				$type = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
				if(in_array($type, $this->accept)) {				
					$name = strtolower(randomString(10)) . '.' . $type;
					$move = move_uploaded_file($_FILES['photo']['tmp_name'], BASE_ROOT . '/upl/' . $name);
					if($move) $photo = $name;
				}
			}

			$data = array_map("addslashes", $_POST);
			$save = $this->CENRO->addComplaint($data['name'], $photo, $data['message']);
			if($save) {
				$_SESSION[$this->CENRO->message] = 'Complaint successfully sent.';
			}
		}
		return array(
			'title' => "Home",
			'header' => true,
			'script' => array(
				'plugins/jquery-1.7.min.js',
				'plugins/jquery.dataTables.min.js',
				'plugins/jquery-ui-1.8.16.custom.min.js',
				'custom/general.js',
				'custom/tables.js'
			),
			'content' => getContents("complaint", ['CENRO'=>$this->CENRO])
		);
	}
}

function baseURL() {
	$currentFile = $_SERVER["PHP_SELF"];
	$urlParts = explode('/', $currentFile);
	unset($urlParts[count($urlParts) - 1]);
	return implode('/', $urlParts) . '/';
}

function getContents($file, $data=null) {
	$path = VIEW_PATH . $file .".php";
	if(file_exists($path)) {
		ob_start();
		if(!empty($data) AND is_array($data)) foreach ($data as $key => $val) $$key = $val;
		include $path;
		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}
}

function getArgument($argument=null) {
	$queue = isset($_GET['q'])? $_GET['q'] : "";
	$args  = explode("/", $queue);
	$argument--;
	return isset($args[$argument])? $args[$argument] : null;
}

function generateUrl($method=null) { return baseURL() . $method; }

function randomString($chars=5) {
	$string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	$result = substr( str_shuffle( $string ), 0, $chars );
	return $result;
}

function formatNumber($number) { 
	return "&#8369;". number_format($number, 2); 
}

function getSecurityQuestions() {
    return array(
        0 => 'In what city or town was your first job?',
        1 => 'In what city or town did your mother and father meet?',
        2 => 'What was your childhood nickname?',
        3 => 'What was the last name of your third grade teacher?',
        4 => 'Where were you when you had your first kiss?'
    );
}

function getUPLFileLink($file, $text=null) {
	return '<a href="' . baseURL() . 'upl/' . $file . '" target="_blank">' . (empty($text)? $file : $text) . '</a>';
}

function getPrograms() {
	return array(
		1 => "Land, Air and Water Quality Management",
		2 => "Urban Forestry",
		3 => "Nature's Concervancy",
		4 => "Solid Waste Management",
		5 => "Rivers and Creeks Rehabilitation"
	);
}

function getRecommendations() {
	return array(
		1 => "Site Inspection",
		2 => "Interview",
		3 => "Clearance",
		4 => "Oath"
	);
}