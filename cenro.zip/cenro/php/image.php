<?php
class Image {
 
	public static function uploadFileImage($inputFileName, $destination='', $w=NULL, $h=NULL) {

		$errors = array();
		$destination = ($destination=='')? BASE_ROOT . 'upload/' : $destination;
		
		if(!isset($_FILES[$inputFileName])) {
			$errors[] = 'Undefined index ' . $inputFileName . ' on file upload.';
		} elseif(isset($_FILES[$inputFileName]['error']) AND $_FILES[$inputFileName]['error'] > 0) {
			switch ($_FILES[$inputFileName]['error']) {
				case UPLOAD_ERR_OK:
					#There is no error, the file uploaded with success.
					$fileError = '';
					break;
				case UPLOAD_ERR_INI_SIZE:
					#The uploaded file exceeds the upload_max_filesize directive in php.ini.
					$fileError = 'The uploaded file exceeds the maximum file size limit.';
					break;
				case UPLOAD_ERR_FORM_SIZE:
					#The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.
					$fileError = 'The uploaded file exceeds the maximum file size limit.';
					break;
				case UPLOAD_ERR_PARTIAL:
					#$response = 'The uploaded file was only partially uploaded.';
					$fileError = '';
					break;
				case UPLOAD_ERR_NO_FILE:
					$fileError = 'No file was uploaded.';
					break;
				case UPLOAD_ERR_NO_TMP_DIR:
					$fileError = 'Missing a temporary folder. Introduced in PHP 4.3.10 and PHP 5.0.3.';
					break;
				case UPLOAD_ERR_CANT_WRITE:
					$fileError = 'Failed to write file to disk. Introduced in PHP 5.1.0.';
					break;
				case UPLOAD_ERR_EXTENSION:
					$fileError = 'File upload stopped by extension. Introduced in PHP 5.2.0.';
					break;
				default:
					$fileError = 'Unknown error';
				break;
			}
		 	$errors[] = $fileError;
		} elseif($_FILES[$inputFileName]['size'] > 0){
			
			$fileName = $_FILES[$inputFileName]['name'];
			$tmpName  = $_FILES[$inputFileName]['tmp_name'];
			$fileSize = $_FILES[$inputFileName]['size'];
			$fileType = $_FILES[$inputFileName]['type'];

			$path_parts = pathinfo($fileName);
			$extension	= strtolower($path_parts['extension']);
		
			if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {
				$errors[] = 'Unknown Image extension.';
			} else {
				if ($fileSize > (MAXUPLOADSIZE*1024)) {
					$errors[] = 'You have exceeded the size limit';
				}
				
				if(count($errors)==0){
					$tmp_image = rand(12345678, 98765432) . '_' . rand(12345678, 98765432) . '.' . $extension;
					$upload_img= move_uploaded_file($tmpName, $destination . $tmp_image);
					if($upload_img){
						list($width,$height) = getimagesize($destination . $tmp_image);
						if(($width>MAXIMAGEWIDTH) || !is_null($w) || !is_null($h)){
							$newwidth	= (is_null($w))? MAXIMAGEWIDTH : $w;
							$newheight	= (is_null($h))? ceil(($height/$width)*$newwidth) : $h;
							$upl_image	= rand(12345678, 98765432) . '_' . rand(12345678, 98765432) . '.' . $extension;
							$resize		= self::resizeImage($destination . $tmp_image, $newwidth, $newheight, $destination . $upl_image);
							if($resize){
								$success['original']= $fileName;
								$success['size'] 	= $fileSize;
								$success['type'] 	= $fileType;
								$success['name'] 	= $upl_image; 
								unlink($destination . $tmp_image);
							} else
								$errors[] = 'Can not resize the file';
						} else {
							$success['original']= $fileName;
							$success['size'] 	= $fileSize;
							$success['type'] 	= $fileType;
							$success['name'] 	= $tmp_image; 
						}
					}else
						$errors[] = 'Can not upload file';
				}
			}
		}
		return count($errors)? array('error'=>$errors) : array('success'=>$success);
	}
	
	public static function resizeImage($sourceImage, $newWidth, $newHeight, $destImage){
		$ext = strtolower(pathinfo($sourceImage, PATHINFO_EXTENSION));
		if(in_array($ext, array("jpg","jpeg","png","gif"))){
	    	if($ext=="jpg" || $ext=="jpeg"){
	    		$img = imagecreatefromjpeg($sourceImage);
	    	}elseif($ext=="png"){
	    		$img = imagecreatefrompng($sourceImage);
	    	}else
				$img = imagecreatefromgif($sourceImage);
		} else return false;
		list($width,$height) = getimagesize($sourceImage);
		$newWidth	= ($newWidth>$width)? $width : $newWidth;
		$newHeight	= ($newHeight>$height)? $height : $newHeight;
	    $tmp_img = imagecreatetruecolor($newWidth, $newHeight);
	   	imagecopyresampled( $tmp_img, $img, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height );
	    ob_start();
	    imagejpeg($tmp_img, NULL, 100);
	    $ob = ob_get_clean();
	    $fp = fopen($destImage,'w');
	    $fw = fwrite ($fp, $ob);
	    fclose ($fp);
		return ($fw===false)? false : true;
	}
}
