<?php 
class CENRO extends TABLE {

	var $access, $upload, $shadow, $message = 'cenro_message', $warning = 'cenro_warning';

	function __construct() {
		parent::__construct();
		$this->access = new USER;
		$this->shadow = BASE_ROOT . '/shw/';
        $this->upload = BASE_ROOT . '/upl/';
    }

    public function escape($string) {
        $string = get_magic_quotes_gpc()? stripslashes($string) : $string;
        $string = addslashes($string);
        return $string;
    }

    public function signin($name, $pass) {
        $this->setTable('user');
        $data = $this->select(array('*'), array(array('user','=', $name), array('user.id', '=', 'salt.id', true), array('user.deleted', '=', 0), array('salt.deleted', '=', 0)), array('salt'));
        if($data) {
            $data = $data[0];
            $prefix = $data['prefix'];
            $suffix = $data['suffix'];
            $shadow = $prefix . $suffix . ".txt";
            $prefix = md5($prefix);
            $suffix = sha1($suffix);
            $rpword = sha1($pass);
            $rpword = md5($rpword);
            $rpword = base64_encode( $prefix.$rpword.$suffix );
            $rpword = md5($rpword);
            $rpword = sha1($rpword);
            $rpword = trim($rpword);
            $dbpass = trim($data['pass']);
            if(($rpword==$dbpass) AND ($pass==$this->getContent($shadow))) {
                $this->access->setUser($data['id']);
                $this->access->setName($data['user']);
                $this->access->setType($data['type']);
                return true;
            } else
                return false;
        } else
            return false;
    }

    public function mkeShadow($file, $content){
        chmod($this->shadow, 0777);
        $fp = fopen($this->shadow.$file, 'w+') or die("mkeShadow()");
        if($fp){
            fwrite($fp, $content);
            fclose($fp);
        }
        chmod($this->shadow, 0600);
        return $this;
    }

    public function getShadow($id) {
        $this->setTable('salt');
        $data = $this->select(array('*'), array(array('id','=', $id)));
        return $data[0]['prefix'].$data[0]['suffix'];
    }

    public function remShadow($file){
        chmod($this->shadow, 0777);
        unlink($this->shadow.$file);
        chmod($this->shadow, 0600);
        return $this;
    }

    public function getContent($file){
        chmod($this->shadow, 0777);
        $content = trim(file_get_contents($this->shadow.$file));
        chmod($this->shadow, 0600);
        return $content;
    }

    public function changeUsername($name, $pass) {
        if($pass==$this->getContent($this->getShadow($this->access->getUser()) . ".txt")) {
            if(strlen($name)<6) return 1;
            $this->setTable('user');
            $this->id = $this->access->getUser();
            $this->user = $name;
            $update = $this->update();
            if($update) {
                $this->access->setName($name);
                return 2;
            }
        }
        return 0;
    }

    public function changePassword($opass, $npass, $cpass) {
        $i = $this->access->getUser();
        $p = $this->getContent($this->getShadow($i) . ".txt");
        if ($opass==$p) {
            if($npass==$cpass) {
                $newpass = $this->escape($npass);
                if(strlen($newpass)<6) return 2;
                $prefix = randomString(10);
                $suffix = randomString(10);
                $newPrefix = $prefix;
                $newSuffix = $suffix;
                $prefix = md5($prefix);
                $suffix = sha1($suffix);
                $rpword = sha1($newpass);
                $rpword = md5($rpword);
                $rpword = base64_encode( $prefix.$rpword.$suffix );
                $rpword = md5($rpword);
                $rpword = sha1($rpword);
                $rpword = trim($rpword);

                $this->setTable('user');
                $this->id = $i;
                $this->pass = $rpword;
                $this->update();
                $this->remShadow($this->getShadow($i) . ".txt")->mkeShadow($newPrefix . $newSuffix . ".txt", $newpass);
                $this->pass = null;
                $this->setTable('salt');
                $this->id = $i;
                $this->prefix = $newPrefix;
                $this->suffix = $newSuffix;
                $this->update();
                return 3;
            } else 
                return 1;
        } 
        return 0;
    }

    public function changeSecurity($sque, $sans, $id) {
        $this->setTable('user');
        $this->id = $id;
        $this->sque = $sque;
        $this->sans = $sans;
        return $this->update();
    }

    public function addUserAccount($name, $pass, $type=0, $apps=0) {
        $prefix = $dbpref = randomString(10);
        $suffix = $dbsuff = randomString(10);
        $shadow = $prefix . $suffix . ".txt";
        $prefix = md5($prefix);
        $suffix = sha1($suffix);
        $rpword = sha1($pass);
        $rpword = md5($rpword);
        $rpword = base64_encode($prefix.$rpword.$suffix);
        $rpword = md5($rpword);
        $rpword = sha1($rpword);
        $rpword = trim($rpword);
        $userID = $this->addUser(trim($name), $rpword, $type, $apps);
        if($userID) {
            $this->addSalt($userID, $dbpref, $dbsuff);
            $this->mkeShadow($shadow, $pass);
            return $userID;
        }
    }

    public function setUserAccount($name, $pass, $id) {
        $user = $this->getUser($id);
        $file = $user['file'] . ".txt";
        if($this->getContent($file)==$pass) $rpword = $user['pass'];
        else {
            $prefix = $dbpref = randomString(10);
            $suffix = $dbsuff = randomString(10);
            $shadow = $prefix . $suffix . ".txt";
            $prefix = md5($prefix);
            $suffix = sha1($suffix);
            $rpword = sha1($pass);
            $rpword = md5($rpword);
            $rpword = base64_encode( $prefix.$rpword.$suffix );
            $rpword = md5($rpword);
            $rpword = sha1($rpword);
            $rpword = trim($rpword);    
            $this->mkeShadow($shadow, $pass)->remShadow($file);
            $this->setSalt($id, $dbpref, $dbsuff);
        }
        return $this->setUser($name, $rpword, $id);
    }

    public function deleteUserAccount($id) {
        $user = $this->deleteUser($id);
        $salt = $this->deleteSalt($id);
        return ($user AND $salt)? true : false;
    }

    private function deleteUser($id) {
        $this->setTable('user');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }

    private function deleteSalt($id) {
        $this->setTable('salt');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }

    private function setUser($user, $pass, $id) {
        $this->setTable('user');
        $this->id = $id;
        $this->user = $user;
        $this->pass = $pass;
        return $this->update();
    }

    private function addUser($user, $pass, $type=0, $apps=0) {
        $this->setTable('user');
        $this->user = $user;
        $this->pass = $pass;
        $this->type = $type;
        $this->apps = $apps;
        return $this->create();
    }

    private function addSalt($id, $prefix, $suffix) {
        $this->setTable('salt');
        $this->id = $id;
        $this->prefix = $prefix;
        $this->suffix = $suffix;
        return $this->create();
    }

    private function setSalt($id, $prefix, $suffix) {
        $this->setTable('salt');
        $this->id = $id;
        $this->prefix = $prefix;
        $this->suffix = $suffix;
        return $this->update();
    }

    public function getForgotPassword($user, $sque, $sans) {
        $this->setTable('user');
        $data =  $this->select(
            array('CONCAT(salt.prefix,salt.suffix) as file'), 
            array(
                array('user.id', '=', 'salt.id', true),
                array('user','=', $user), 
                array('sque','=', $sque), 
                array('sans','=', $sans), 
                array('user.deleted', '=', 0), 
                array('salt.deleted', '=', 0)
            ), 
            array('salt')
        );
        return $data[0]['file'];
    }

    public function getUsers($type=0) {
        $this->setTable('user');
        $this->setOrder(array(array('user.id','DESC')));
        return $this->select(array('user.*','CONCAT(salt.prefix,salt.suffix) as file'), array(array('user.deleted', '=', 0), array('salt.deleted', '=', 0), array('user.type', '=', $type), array('user.id', '=', 'salt.id', true)), array('salt'));
    }

    public function getUser($id) {
        $this->setTable('user');
        $data = $this->select(array('user.*','CONCAT(salt.prefix,salt.suffix) as file'), array(array('user.id', '=', 'salt.id', true), array('user.id', '=', $id)), array('salt'));
        return $data[0];
    } 

    public function getUserByApps($apps) {
        $this->setTable('user');
        $data = $this->select(array('*'), array(array('apps', '=', $apps)));
        return $data[0];
    }

    public function addProfile($uid, $pid, $image, $lname, $fname, $mname, $email, $contact, $address, $position) {
        $this->setTable('profiles');
        $this->uid = $uid;
        $this->pid = $pid;
        $this->image = $image;
        $this->lname = $lname;
        $this->fname = $fname; 
        $this->mname = $mname;
        $this->email = $email;
        $this->contact = $contact;
        $this->address = $address;
        $this->position = $position;
        return $this->create();
    }

    public function setProfile($pid, $image, $lname, $fname, $mname, $email, $contact, $address, $position, $id) {
        $this->setTable('profiles');
        $this->id = $id;
        $this->pid = $pid;
        $this->image = $image;
        $this->lname = $lname;
        $this->fname = $fname; 
        $this->mname = $mname;
        $this->email = $email;
        $this->contact = $contact;
        $this->address = $address;
        $this->position = $position;
        return $this->update();
    }

    public function getProfileByUID($uid) {
        $this->setTable('profiles');
        $data = $this->select(array('*'), array(array('uid','=', $uid)));
        return $data[0];
    }

    public function getValidatorPID($uid) {
        $this->setTable('profiles');
        $data = $this->select(array('pid'), array(array('uid','=', $uid)));
        return $data[0]['pid'];
    }

    public function getService($id) {
        $this->setTable('services');
        $data = $this->select(array('*'), array(array('id','=', $id)));
        return $data[0];
    }

    public function getServices($pid) {
        $this->setTable('services');
        $this->setOrder(array(array('name')));
        return $this->select(array('*'), array(array('pid', '=', $pid), array('deleted', '=', 0)));
    }

    public function addService($pid, $name, $description) {
        $this->setTable('services');
        $this->pid = $pid;
        $this->name = $name;
        $this->description = $description;
        return $this->create();
    }

    public function setService($name, $description, $id) {
        $this->setTable('services');
        $this->id = $id;
        $this->name = $name;
        $this->description = $description;
        return $this->update();
    }

    public function deleteService($id) {
        $this->setTable('services');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }

    public function getRequirements($sid) {
        $this->setTable('requirements');
        $this->setOrder(array(array('id')));
        return $this->select(array('*'), array(array('sid', '=', $sid), array('deleted', '=', 0)));
    }

    public function getRequirement($id) {
        $this->setTable('requirements');
        $data = $this->select(array('*'), array(array('id', '=', $id)));
        return $data[0];
    }

    public function getRequirementName($id) {
        $this->setTable('requirements');
        $data = $this->select(array('name'), array(array('id', '=', $id)));
        return $data[0]['name'];
    }

    public function addRequirement($sid, $name) {
        $this->setTable('requirements');
        $this->sid = $sid;
        $this->name = $name;
        return $this->create();
    }

    public function setRequirement($name, $id) {
        $this->setTable('requirements');
        $this->id = $id;
        $this->name = $name;
        return $this->update();
    }

    public function deleteRequirement($id) {
        $this->setTable('requirements');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }

    public function getViolations() {
        $this->setTable('violations');
        $this->setOrder(array(array('name')));
        return $this->select(array('*'), array(array('deleted', '=', 0)));
    }

    public function getViolation($id) {
        $this->setTable('violations');
        $data = $this->select(array('*'), array(array('id', '=', $id)));
        return $data[0];
    }

    public function addViolation($name, $description) {
        $this->setTable('violations');
        $this->name = $name;
        $this->description = $description;
        return $this->create();
    }

    public function setViolation($name, $description, $id) {
        $this->setTable('violations');
        $this->id = $id;
        $this->name = $name;
        $this->description = $description;
        return $this->update();
    }

    public function deleteViolation($id) {
        $this->setTable('violations');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }

    public function getApplication($id) {
        $this->setTable('applications');
        $data = $this->select(array('applications.*', 'services.name as service'), array(array('applications.id', '=', $id), array('applications.sid', '=', 'services.id', true)), array("services"));
        return $data[0];
    }

    public function getApplicationHistory($id) {
        $this->setTable('applications');
        $data = $this->select(array('history'), array(array('id', '=', $id)));
        return $data[0]['history'];
    }

    public function getApplications($uid) {
        $this->setTable('applications');
        $this->setOrder(array(array('updated','DESC')));
        return $this->select(array('applications.*', 'services.name as service'), array(array('applications.sid', '=', 'services.id', true), array('applications.deleted', '=', 0), array('uid', '=', $uid)), array("services"));
    }

    public function getApplicationsWithViolations() {
        $this->setTable('applications');
        $this->setOrder(array(array('updated','DESC')));    
        return $this->select(
            array('applications.*', 'services.name as service'), 
            array(
                array('applications.sid', '=', 'services.id', true), 
                array('applications.deleted', '=', 0), 
                array('applications.status', '=', 0),
                array('applications.violations', '<>', '')
            ), 
            array("services")
        );
    }

    public function getApplicationsByStatus($status, $pid=false) {
        $this->setTable('applications');
        $this->setOrder(array(array('updated','DESC')));
        $where = array(
            array('applications.sid', '=', 'services.id', true), 
            array('applications.deleted', '=', 0), 
            array('applications.status', '=', $status)
        );
        if($pid) array_push($where, array('applications.pid', '=', $pid));
        return $this->select(array('applications.*', 'services.name as service'), $where, array("services"));
    }

    public function getApplicationsByStatusThisMonth($status, $month, $year) {
        $this->setTable('applications');
        $this->setOrder(array(array('created','DESC')));        
        return $this->select(
            array('applications.*', 'services.name as service'), 
            array(
                array('applications.sid', '=', 'services.id', true), 
                array('applications.deleted', '=', 0), 
                array('applications.status', '=', $status),
                array('MONTH(applications.created)', '=', $month),
                array('YEAR(applications.created)', '=', $year)
            ), 
            array("services")
        );
    }

    public function getApplicationsWithViolationsThisMonth($month, $year) {
        $this->setTable('applications');
        $this->setOrder(array(array('created','DESC')));    
        return $this->select(
            array('applications.*', 'services.name as service'), 
            array(
                array('applications.sid', '=', 'services.id', true), 
                array('applications.deleted', '=', 0), 
                array('applications.status', '=', 0),
                array('applications.violations', '<>', ''),
                array('MONTH(applications.created)', '=', $month),
                array('YEAR(applications.created)', '=', $year)
            ), 
            array("services")
        );
    }

    public function addApplication($pid, $sid, $uid, $fname, $lname, $mname, $company, $address, $requirements, $created) {
        $this->setTable('applications');
        $this->pid = $pid;
        $this->sid = $sid;
        $this->uid = $uid;
        $this->fname = $fname;
        $this->lname = $lname;
        $this->mname = $mname;
        $this->company = $company;
        $this->address = $address;
        $this->requirements = $requirements;        
        $this->created = $created;
        return $this->create();
    }

    public function updateApplication($fname, $lname, $mname, $company, $address, $requirements, $pid, $sid, $id) {
        $this->setTable('applications');        
        $this->fname = $fname;
        $this->lname = $lname;
        $this->mname = $mname;
        $this->company = $company;
        $this->address = $address;
        $this->requirements = $requirements;
        $this->pid = $pid;
        $this->sid = $sid;
        $this->id = $id;
        return $this->update();
    }

    public function deleteApplication($id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }

    public function verifyApplication($id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->status = 1;
        return $this->update();
    }

    public function approveApplication($id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->status = 2;
        return $this->update();
    }

    public function disapproveApplication($id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->status = 0;
        $this->actionOn = '';
        $this->actionBy = '';
        return $this->update();
    }

    public function remarksApplication($remarks, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->remarks = $remarks;
        return $this->update();
    }

    public function recommendationApplication($recommendation, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->recommendation = $recommendation;
        return $this->update();
    }

    public function actionOnApplication($actionOn, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->actionOn = $actionOn;
        return $this->update();
    }

    public function actionByApplication($actionBy, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->actionBy = $actionBy;
        return $this->update();
    }

    public function setApplicationViolations($violations, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->violations = $violations;
        return $this->update();
    }

    public function setApplicationHistory($history, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->history = $history;
        return $this->update();
    }

    public function setApplicationRequirements($requirements, $id) {
        $this->setTable('applications');
        $this->id = $id;
        $this->requirements = $requirements;
        return $this->update();
    }

    public function deleteApplicant($apps) {
        $user = $this->getUserByApps($apps);
        return $this->deleteUserAccount($user['id']);
    }

    public function addComplaint($name, $photo, $message) {
        $this->setTable('complaints');
        $this->name = $name;
        $this->photo = $photo;
        $this->message = $message;
        return $this->create();
    }

    public function getComplaints() {
        $this->setTable('complaints');
        $this->setOrder(array(array('date','DESC')));
        return $this->select(array('*'), array(array('deleted', '=', 0)));
    }

    public function getComplaint($id) {
        $this->setTable('complaints');
        $data = $this->select(array('*'), array(array('id', '=', $id)));
        return $data[0];
    }

    public function deleteComplaint($id) {
        $this->setTable('complaints');
        $this->id = $id;
        $this->deleted = 1;
        return $this->update();
    }
}