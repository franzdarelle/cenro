<?php
class USER {

	var $name, $user, $type;

	function __construct() {
		$this->user = (isset($_SESSION['WEBUSER']['user']))?  $_SESSION['WEBUSER']['user'] : false;
    	$this->name = (isset($_SESSION['WEBUSER']['name']))?  $_SESSION['WEBUSER']['name'] : false;
        $this->type = (isset($_SESSION['WEBUSER']['type']))?  $_SESSION['WEBUSER']['type'] : false;
    }

    public function setUser($user=false) {
    	if($user) $_SESSION['WEBUSER']['user'] = $user;
    	$this->user = $user;
    }

    public function getUser() {
    	return $this->user;
    }

    public function setName($name=false) {
    	if($name) $_SESSION['WEBUSER']['name'] = $name;
    	$this->name = $name;
    }

    public function getName() {
    	return $this->name;
    }

    public function setType($type) {
        $_SESSION['WEBUSER']['type'] = $type;
        $this->type = $type;
    }

    public function getType() {
        return $this->type;
    }

    public function running() {
        return isset($_SESSION['WEBUSER']);
    }
}