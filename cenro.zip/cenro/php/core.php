<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set("Asia/Manila");

$SETTINGS = json_decode(file_get_contents(BASE_ROOT . '/web/settings.json'));
define('DB_HOST', $SETTINGS->DB_HOST);
define('DB_USER', $SETTINGS->DB_USER);
define('DB_PASS', $SETTINGS->DB_PASS);
define('DB_NAME', $SETTINGS->DB_NAME);
define('WEBNAME', $SETTINGS->WEBNAME);
define('ACRONIM', $SETTINGS->ACRONIM);
define('MAXUPLOADSIZE', $SETTINGS->MAXUPLOADSIZE);
define('MAXIMAGEWIDTH', $SETTINGS->MAXIMAGEWIDTH);

class ACCESS {

	var $PDO, $dbHost, $dbUser, $dbPass, $dbName;

    function __construct() {
        $this->Halt()->Load();
    }

    public function Load() {
        $this->dbHost = DB_HOST;
        $this->dbUser = DB_USER;
        $this->dbPass = DB_PASS;
        $this->dbName = DB_NAME;
        try {
            $this->PDO = new PDO('mysql:host='.$this->dbHost.';dbname='.$this->dbName, $this->dbUser, $this->dbPass, array(PDO::ATTR_PERSISTENT => true));
        } catch (PDOException $e) {
            exit("Load(): " . $e->getMessage());
        }
    }

    public function Halt() {
        $this->PDO = null;
        return $this;
    } 
}

class TABLE extends ACCESS {

    var $table;
    var $field = array();
    var $keyID = 'id';
    var $insID;
    var $order;
    var $limit;

    function __construct() {
        parent::Load();
    }

    function __destruct() {
        parent::Halt();
    }

    public function getTables() {
        $table = array();
        $query = $this->PDO->query("SHOW TABLES"); 
        foreach ($query->fetchAll() as $key => $value) {
            $table[] = $value['Tables_in_'.$this->dbName];
        }
        return $table;
    }

    public function setTable($table) {
        if(in_array($table, $this->getTables())) {
            $this->table = $table;
            $this->setVariables();
            return $this;
        } else
            $this->showError('Unknown Table', '<i>' . $table . '</i>');
    }

    public function getTable() {
        return $this->table;
    }

    public function getTableColumns() {
        $columns = array();
        $query = $this->PDO->query("SHOW COLUMNS FROM ".$this->getTable());
        foreach ($query->fetchAll() as $column) $columns[] = $column;
        return $columns;
    }

    public function setVariables() {
        foreach ($this->getTableColumns() as $column) { 
            $this->$column['Field'] = $column['Field'];
            $this->field[] = $this->$column['Field'];
        }
        return $this->setID();
    }

    public function getVariable($var) {
        return $this->$var;
    }

    public function showError($title, $value){
        exit($title . ': ' . $value);
    }

    public function setID($value=null) {
        $pkey = $this->keyID;
        $this->$pkey = $value;
        return $this;
    }

    public function getID() {
        $pkey = $this->keyID;
        return $this->$pkey;
    }

    public function rollback() {
        foreach ($this->field as $field) $this->$field = $field;
    }

    public function setOrder($orders=array()) {
        if(empty($orders)) $this->order = null;
        else {
            $query = ' ORDER BY ';
            foreach ($orders as $o) {
                $string[] = $o[0] . ' ' . (empty($o[1])? 'ASC' : 'DESC');
            }
            $query .= implode(',', $string);
            $this->order = $query;
        }
        return $this;
    }

    public function getOrder() {
        return $this->order;
    }

    public function setLimit($from, $end=0) {
        if($from) $this->limit = ' LIMIT ' . $from;
        else {
            $this->limit = null;
        }
        if($end) $this->limit .= ',' . $end;  
        return $this;
    }

    public function getLimit() {
        return $this->limit;
    }

    public function binder($tables=array()) {
        return implode(", ", array_merge(array($this->getTable()), $tables));
    }

    public function escape($string) {
        $string = get_magic_quotes_gpc()? stripslashes($string) : $string;
        $string = addslashes($string);
        return $string;
    }

    public function create() {
        foreach ($this->field as $field) {
            if(empty($this->$field) OR $this->$field===$field) continue;
            $fields[$field] = (is_string($this->$field))? ("'" . $this->escape($this->$field) . "'") : $this->$field; 
        }
        if(empty($fields)) return false;
        else {
            $query = $this->PDO->query("INSERT INTO " . $this->getTable() . " (" . implode(', ', array_keys($fields)) . ") VALUES (" . implode(', ', array_values($fields)) . ")");
            $this->insID = $this->PDO->lastInsertId();
            $this->rollback();
            return $this->insID;
        }
    }

    public function select($field = array(), $where = array(), $table = array()) {
        $record = array();
        $string = "SELECT " .implode(", ", $field). " FROM " . ((empty($table))? $this->getTable() : $this->binder($table));
        if(!empty($where)) {
            foreach ($where as $w) {
                $others[] = $w[0] . " " . $w[1] . " " . ((is_string($w[2]) AND empty($w[3]))? ("'" . $this->escape($w[2]) . "'") : $w[2]);
            }
            $string .= " WHERE " . implode(" AND ", $others);
        }
        $object = $this->PDO->query($string . $this->getOrder() . $this->getLimit());
        if($object->rowCount())
            $record = $object->fetchAll();
        else {
            $record = $object->fetch(PDO::FETCH_ASSOC);
        }
        if(!empty($record)) foreach ($record as $key => $val) $record[$key] = (is_string($val))? stripslashes($val) : $val;
        $this->setOrder();
        return $record; 
    }

    public function update() {
        foreach ($this->field as $field) {
            if(isset($this->$field)) {
                if(($this->$field===$field) OR ($field==$this->keyID)) continue; 
                else {
                    $fields[] = $field . " = " . ((is_string($this->$field))? ("'" . $this->escape($this->$field) . "'") : $this->$field); 
                }      
            }
        }
        if(empty($fields) OR !$this->getID()) return false;
        else {
            $update = $this->PDO->query("UPDATE " . $this->getTable() . " SET " . implode(', ', $fields) . " WHERE " . $this->keyID . "=" . $this->getID());
            $this->rollback();
            return $update;
        }
    }

    public function delete($truncate=false) {
        if($truncate) $query = "TRUNCATE " . $this->getTable();
        else {
            $query = "DELETE FROM " . $this->getTable();
            if(is_numeric($this->getID())) $query .= " WHERE " . $this->keyID . "=" . $this->getID();
        }
        return $this->PDO->query($query);
    }

    public function extend($table) {
        $class = new TABLE;
        $class->setTable($table);
        return $class;
    }
}